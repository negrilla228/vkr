using System;
using Xunit;
using KadryVotumS.Data;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Tests
{
    // тесты модуля приказов
    public class OrderTests
    {
        private readonly OrderService _svc = new();
        private int _empId;

        public OrderTests()
        {
            AppConfig.UsePostgres = false;
            AppConfig.SqlitePath = "test_order.db";
            using var db = new AppDbContext();
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            AuthService.Login("admin@votum-s.ru", "admin123");
            // создаем тестового сотрудника
            var emp = new Employee { LastName = "Тестов", FirstName = "Тест", BirthDate = new DateTime(1990,1,1), DepartmentId = 1, PositionId = 1, HireDate = DateTime.Today };
            new EmployeeService().Add(emp);
            _empId = emp.Id;
        }

        [Fact]
        public void Create_T1_ReturnsOrder()
        {
            var order = _svc.Create(_empId, "T1", DateTime.Today);
            Assert.NotNull(order);
            Assert.True(order.Id > 0);
        }

        [Fact]
        public void Create_AssignsOrderNumber()
        {
            var order = _svc.Create(_empId, "T1", DateTime.Today);
            Assert.StartsWith("T1-", order.OrderNumber);
        }

        [Fact]
        public void Create_T5_CorrectType()
        {
            var order = _svc.Create(_empId, "T5", DateTime.Today);
            Assert.Equal("T5", order.Type);
        }

        [Fact]
        public void Create_T8_CorrectType()
        {
            var order = _svc.Create(_empId, "T8", DateTime.Today);
            Assert.Equal("T8", order.Type);
        }

        [Fact]
        public void GetAll_AfterCreate_ContainsOrder()
        {
            _svc.Create(_empId, "T1", DateTime.Today);
            var list = _svc.GetAll();
            Assert.NotEmpty(list);
        }

        [Fact]
        public void Create_WithNote_SavesNote()
        {
            var order = _svc.Create(_empId, "T1", DateTime.Today, "тестовое примечание");
            Assert.Equal("тестовое примечание", order.ContentJson);
        }

        [Fact]
        public void GeneratePdf_ValidOrder_ReturnsByteArray()
        {
            var order = _svc.Create(_empId, "T1", DateTime.Today);
            var pdf = _svc.GeneratePdf(order.Id);
            Assert.NotNull(pdf);
            Assert.True(pdf.Length > 100); // PDF не должен быть пустым
        }

        [Fact]
        public void GeneratePdf_StartsWithPdfHeader()
        {
            var order = _svc.Create(_empId, "T1", DateTime.Today);
            var pdf = _svc.GeneratePdf(order.Id);
            // PDF файлы начинаются с %PDF
            Assert.Equal(0x25, pdf[0]); // %
            Assert.Equal(0x50, pdf[1]); // P
        }
    }
}