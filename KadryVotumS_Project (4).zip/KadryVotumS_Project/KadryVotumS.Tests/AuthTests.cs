using Xunit;
using KadryVotumS.Services;
using KadryVotumS.Data;

namespace KadryVotumS.Tests
{
    // тесты модуля аутентификации
    public class AuthTests
    {
        public AuthTests()
        {
            // переключаемся на SQLite для тестов
            AppConfig.UsePostgres = false;
            AppConfig.SqlitePath = "test_auth.db";
            using var db = new AppDbContext();
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
        }

        [Fact]
        public void HashPassword_SameInput_SameOutput()
        {
            var h1 = AuthService.HashPassword("test123");
            var h2 = AuthService.HashPassword("test123");
            Assert.Equal(h1, h2);
        }

        [Fact]
        public void HashPassword_DifferentInput_DifferentOutput()
        {
            var h1 = AuthService.HashPassword("test123");
            var h2 = AuthService.HashPassword("test456");
            Assert.NotEqual(h1, h2);
        }

        [Fact]
        public void Login_ValidCredentials_ReturnsTrue()
        {
            var result = AuthService.Login("admin@votum-s.ru", "admin123");
            Assert.True(result);
            Assert.NotNull(AuthService.CurrentUser);
        }

        [Fact]
        public void Login_WrongPassword_ReturnsFalse()
        {
            var result = AuthService.Login("admin@votum-s.ru", "wrong");
            Assert.False(result);
        }

        [Fact]
        public void Login_NonExistentUser_ReturnsFalse()
        {
            var result = AuthService.Login("nobody@test.ru", "123");
            Assert.False(result);
        }

        [Fact]
        public void Login_EmptyEmail_ReturnsFalse()
        {
            var result = AuthService.Login("", "123");
            Assert.False(result);
        }

        [Fact]
        public void Logout_ClearsCurrentUser()
        {
            AuthService.Login("admin@votum-s.ru", "admin123");
            AuthService.Logout();
            Assert.Null(AuthService.CurrentUser);
        }

        [Fact]
        public void IsAdmin_AfterAdminLogin_ReturnsTrue()
        {
            AuthService.Login("admin@votum-s.ru", "admin123");
            Assert.True(AuthService.IsAdmin);
        }
    }
}