using System;
using System.Linq;
using Xunit;
using KadryVotumS.Data;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Tests
{
    // тесты модуля сотрудников
    public class EmployeeTests
    {
        private readonly EmployeeService _svc = new();

        public EmployeeTests()
        {
            AppConfig.UsePostgres = false;
            AppConfig.SqlitePath = "test_emp.db";
            using var db = new AppDbContext();
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            // логинимся для аудита
            AuthService.Login("admin@votum-s.ru", "admin123");
        }

        private Employee MakeEmployee(string last = "Тестов", string first = "Тест")
        {
            return new Employee
            {
                LastName = last, FirstName = first,
                BirthDate = new DateTime(1990, 1, 1),
                DepartmentId = 1, PositionId = 1,
                HireDate = DateTime.Today.AddMonths(-6)
            };
        }

        [Fact]
        public void Add_ValidEmployee_AssignsId()
        {
            var emp = MakeEmployee();
            _svc.Add(emp);
            Assert.True(emp.Id > 0);
        }

        [Fact]
        public void Add_Employee_AssignsTabNumber()
        {
            var emp = MakeEmployee();
            _svc.Add(emp);
            Assert.False(string.IsNullOrEmpty(emp.TabNumber));
        }

        [Fact]
        public void GetAll_AfterAdd_ContainsEmployee()
        {
            _svc.Add(MakeEmployee("Иванов", "Иван"));
            var list = _svc.GetAll();
            Assert.Contains(list, e => e.LastName == "Иванов");
        }

        [Fact]
        public void GetAll_SearchByName_FiltersCorrectly()
        {
            _svc.Add(MakeEmployee("Петров", "Петр"));
            _svc.Add(MakeEmployee("Сидоров", "Сидор"));
            var result = _svc.GetAll(search: "Петров");
            Assert.Single(result);
            Assert.Equal("Петров", result[0].LastName);
        }

        [Fact]
        public void GetAll_FilterByDepartment_Works()
        {
            _svc.Add(MakeEmployee("Козлов"));
            var result = _svc.GetAll(deptId: 1);
            Assert.All(result, e => Assert.Equal(1, e.DepartmentId));
        }

        [Fact]
        public void GetById_ExistingId_ReturnsEmployee()
        {
            var emp = MakeEmployee();
            _svc.Add(emp);
            var found = _svc.GetById(emp.Id);
            Assert.NotNull(found);
            Assert.Equal(emp.LastName, found.LastName);
        }

        [Fact]
        public void GetById_NonExistingId_ReturnsNull()
        {
            var found = _svc.GetById(99999);
            Assert.Null(found);
        }

        [Fact]
        public void Delete_SetsStatusUvolen()
        {
            var emp = MakeEmployee();
            _svc.Add(emp);
            _svc.Delete(emp.Id);
            var found = _svc.GetById(emp.Id);
            Assert.Equal("Уволен", found?.Status);
        }

        [Fact]
        public void Delete_SetsFireDate()
        {
            var emp = MakeEmployee();
            _svc.Add(emp);
            _svc.Delete(emp.Id);
            var found = _svc.GetById(emp.Id);
            Assert.NotNull(found?.FireDate);
        }

        [Fact]
        public void FullName_WithMiddleName_FormatsCorrectly()
        {
            var emp = new Employee { LastName = "Иванов", FirstName = "Иван", MiddleName = "Иванович" };
            Assert.Equal("Иванов Иван Иванович", emp.FullName);
        }

        [Fact]
        public void FullName_WithoutMiddleName_NoTrailingSpace()
        {
            var emp = new Employee { LastName = "Иванов", FirstName = "Иван" };
            Assert.Equal("Иванов Иван", emp.FullName);
        }

        [Fact]
        public void GetVacationBalance_NewEmployee_Returns14()
        {
            // сотрудник принят 6 месяцев назад, должно быть ~14 дней
            var emp = MakeEmployee();
            _svc.Add(emp);
            var balance = _svc.GetVacationBalance(emp.Id);
            Assert.InRange(balance, 12, 16); // примерно 14
        }

        [Fact]
        public void GetVacationBalance_NonExistentEmployee_ReturnsZero()
        {
            Assert.Equal(0, _svc.GetVacationBalance(99999));
        }

        [Fact]
        public void GetStats_ReturnsNonNegativeValues()
        {
            var stats = _svc.GetStats();
            Assert.True(stats.total >= 0);
            Assert.True(stats.hired >= 0);
            Assert.True(stats.fired >= 0);
            Assert.True(stats.onVac >= 0);
        }
    }
}