using System;
using Xunit;
using KadryVotumS.Data;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Tests
{
    // тесты модуля отпусков
    public class VacationTests
    {
        private readonly VacationService _svc = new();
        private int _empId;

        public VacationTests()
        {
            AppConfig.UsePostgres = false;
            AppConfig.SqlitePath = "test_vac.db";
            using var db = new AppDbContext();
            db.Database.EnsureDeleted();
            db.Database.EnsureCreated();
            AuthService.Login("admin@votum-s.ru", "admin123");
            var emp = new Employee { LastName = "Тестов", FirstName = "Тест", BirthDate = new DateTime(1990,1,1), DepartmentId = 1, PositionId = 1, HireDate = DateTime.Today.AddYears(-2) };
            new EmployeeService().Add(emp);
            _empId = emp.Id;
        }

        [Fact]
        public void Add_ValidVacation_Succeeds()
        {
            var vac = new Vacation { EmployeeId = _empId, StartDate = DateTime.Today.AddDays(10), EndDate = DateTime.Today.AddDays(23), Type = "Ежегодный оплачиваемый" };
            _svc.Add(vac);
            Assert.True(vac.Id > 0);
        }

        [Fact]
        public void Add_ExceedingBalance_ThrowsException()
        {
            // у сотрудника ~56 дней (2 года), но попробуем 100
            var vac = new Vacation { EmployeeId = _empId, StartDate = DateTime.Today, EndDate = DateTime.Today.AddDays(99), Type = "Ежегодный оплачиваемый" };
            Assert.Throws<Exception>(() => _svc.Add(vac));
        }

        [Fact]
        public void Add_SickLeave_NoBalanceCheck()
        {
            // больничный не проверяет баланс
            var vac = new Vacation { EmployeeId = _empId, StartDate = DateTime.Today, EndDate = DateTime.Today.AddDays(99), Type = "По болезни" };
            _svc.Add(vac); // не должно бросать исключение
            Assert.True(vac.Id > 0);
        }

        [Fact]
        public void GetAll_AfterAdd_ContainsVacation()
        {
            _svc.Add(new Vacation { EmployeeId = _empId, StartDate = DateTime.Today, EndDate = DateTime.Today.AddDays(5), Type = "Учебный" });
            var list = _svc.GetAll();
            Assert.NotEmpty(list);
        }

        [Fact]
        public void Days_CalculatesCorrectly()
        {
            var vac = new Vacation { StartDate = new DateTime(2026,1,1), EndDate = new DateTime(2026,1,14) };
            Assert.Equal(14, vac.Days);
        }

        [Fact]
        public void Days_SingleDay_ReturnsOne()
        {
            var vac = new Vacation { StartDate = DateTime.Today, EndDate = DateTime.Today };
            Assert.Equal(1, vac.Days);
        }

        [Fact]
        public void Delete_RemovesVacation()
        {
            var vac = new Vacation { EmployeeId = _empId, StartDate = DateTime.Today, EndDate = DateTime.Today.AddDays(3), Type = "Учебный" };
            _svc.Add(vac);
            _svc.Delete(vac.Id);
            // после удаления список должен быть пустым (или не содержать этот отпуск)
            var list = _svc.GetAll();
            Assert.DoesNotContain(list, v => v.Id == vac.Id);
        }
    }
}