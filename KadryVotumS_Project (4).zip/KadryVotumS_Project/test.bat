@echo off
echo Запуск тестов...
dotnet test KadryVotumS.Tests\KadryVotumS.Tests.csproj -v normal
pause
