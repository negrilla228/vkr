# Кадры - Вотум-С
## Программа учета кадров организации

### Быстрый старт (БЕЗ PostgreSQL - для защиты)
1. Распакуйте архив
2. Откройте cmd в папке проекта
3. Запустите build.bat (или вручную: dotnet publish ...)
4. Готовый exe в папке publish/
5. Запустите publish/KadryVotumS.exe
6. Логин: admin@votum-s.ru, пароль: admin123

Программа сама определяет: есть PostgreSQL - работает с ним, нет - использует SQLite (файл kadry.db рядом с exe).

### Запуск тестов
test.bat или: dotnet test KadryVotumS.Tests/KadryVotumS.Tests.csproj

### Сборка self-contained exe (один файл, без .NET Runtime)
dotnet publish KadryVotumS/KadryVotumS.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true -o publish

### Технологии
- C# / .NET 8.0 / WPF (MVVM)
- Entity Framework Core 8 (PostgreSQL + SQLite)
- QuestPDF (PDF приказы)
- ClosedXML (Excel отчеты)
- Serilog (логирование)
- xUnit (37 тестов)

### Автор
Мирзоев Даниил Эркинович
