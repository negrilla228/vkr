using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class VacationsPage : Page
    {
        public VacationsPage() { InitializeComponent(); Load(); }
        private void Load() { dg.ItemsSource = new VacationService().GetAll(); }
        private void AddClick(object s, RoutedEventArgs e) { var aw = new AddVacationWindow(); aw.Owner = Window.GetWindow(this); if (aw.ShowDialog() == true) Load(); }
    }
}