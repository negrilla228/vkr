using System;
using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class AddVacationWindow : Window
    {
        public AddVacationWindow()
        {
            InitializeComponent();
            cmbE.ItemsSource = new EmployeeService().GetAll();
            cmbE.SelectionChanged += (s,e) => { if (cmbE.SelectedValue is int id) txtBal.Text = $"Остаток: {new EmployeeService().GetVacationBalance(id)} дней"; };
        }
        private void SaveClick(object s, RoutedEventArgs e)
        {
            if (cmbE.SelectedValue==null||dp1.SelectedDate==null||dp2.SelectedDate==null){txtE.Text="Заполните все поля";return;}
            if (dp2.SelectedDate<dp1.SelectedDate){txtE.Text="Дата окончания раньше начала";return;}
            try { new VacationService().Add(new Vacation{EmployeeId=(int)cmbE.SelectedValue,StartDate=dp1.SelectedDate.Value,EndDate=dp2.SelectedDate.Value,Type=(cmbT.SelectedItem as ComboBoxItem)?.Content?.ToString()??"Ежегодный оплачиваемый"}); DialogResult=true; Close(); }
            catch(Exception ex){txtE.Text=ex.Message;}
        }
        private void CancelClick(object s, RoutedEventArgs e) => Close();
    }
}