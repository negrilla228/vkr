using System;
using System.Windows;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class EmployeeEditWindow : Window
    {
        private readonly Employee? _ex;
        private readonly EmployeeService _svc = new();

        public EmployeeEditWindow(Employee? emp = null)
        {
            InitializeComponent();
            var ss = new StaffingService();
            fDept.ItemsSource = ss.GetDepartments();
            fPos.ItemsSource = ss.GetPositions();
            fHire.SelectedDate = DateTime.Today;

            if (emp != null)
            {
                _ex = emp; Title = "Редактирование: " + emp.FullName;
                fLast.Text = emp.LastName; fFirst.Text = emp.FirstName; fMid.Text = emp.MiddleName;
                fBirth.SelectedDate = emp.BirthDate; fPass.Text = emp.Passport;
                fSnils.Text = emp.Snils; fInn.Text = emp.Inn; fPhone.Text = emp.Phone;
                fDept.SelectedValue = emp.DepartmentId; fPos.SelectedValue = emp.PositionId;
                fHire.SelectedDate = emp.HireDate;
            }
        }

        private void Save(object s, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(fLast.Text) || string.IsNullOrWhiteSpace(fFirst.Text) ||
                fBirth.SelectedDate == null || fDept.SelectedValue == null ||
                fPos.SelectedValue == null || fHire.SelectedDate == null)
            { txtErr.Text = "Заполните обязательные поля (*)"; return; }

            try
            {
                var emp = _ex ?? new Employee();
                emp.LastName = fLast.Text.Trim(); emp.FirstName = fFirst.Text.Trim();
                emp.MiddleName = fMid.Text.Trim(); emp.BirthDate = fBirth.SelectedDate.Value;
                emp.Passport = fPass.Text.Trim(); emp.Snils = fSnils.Text.Trim();
                emp.Inn = fInn.Text.Trim(); emp.Phone = fPhone.Text.Trim();
                emp.DepartmentId = (int)fDept.SelectedValue; emp.PositionId = (int)fPos.SelectedValue;
                emp.HireDate = fHire.SelectedDate.Value;

                if (_ex != null) _svc.Update(emp); else _svc.Add(emp);
                DialogResult = true; Close();
            }
            catch (Exception ex) { txtErr.Text = ex.InnerException?.Message ?? ex.Message; }
        }

        private void Cancel(object s, RoutedEventArgs e) => Close();
    }
}