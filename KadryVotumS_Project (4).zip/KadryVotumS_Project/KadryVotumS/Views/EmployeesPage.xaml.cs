using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class EmployeesPage : Page
    {
        private readonly EmployeeService _svc = new();
        public EmployeesPage()
        {
            InitializeComponent();
            var depts = new StaffingService().GetDepartments();
            depts.Insert(0, new Department { Id = 0, Name = "Все отделы" });
            cmbDept.ItemsSource = depts; cmbDept.SelectedIndex = 0;
            Load();
        }
        private void Load()
        {
            int? d = null;
            if (cmbDept?.SelectedValue is int id && id > 0) d = id;
            dg.ItemsSource = _svc.GetAll(txtSearch?.Text, d);
        }
        private void SearchChanged(object s, TextChangedEventArgs e) => Load();
        private void DeptChanged(object s, SelectionChangedEventArgs e) => Load();
        private void ResetClick(object s, RoutedEventArgs e) { txtSearch.Text = ""; cmbDept.SelectedIndex = 0; }
        private void AddClick(object s, RoutedEventArgs e) { var w = new EmployeeEditWindow(); w.Owner = Window.GetWindow(this); if (w.ShowDialog() == true) Load(); }
        private void RowDbl(object s, MouseButtonEventArgs e)
        { if (dg.SelectedItem is Employee emp) { var cw = new EmployeeCardWindow(emp.Id); cw.Owner = Window.GetWindow(this); cw.ShowDialog(); Load(); } }
    }
}