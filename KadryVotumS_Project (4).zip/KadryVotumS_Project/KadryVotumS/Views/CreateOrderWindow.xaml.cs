using System;
using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;
using Microsoft.Win32;

namespace KadryVotumS.Views
{
    public partial class CreateOrderWindow : Window
    {
        private readonly int _empId;
        private readonly OrderService _svc = new();
        public CreateOrderWindow(int empId) { InitializeComponent(); _empId = empId; dpD.SelectedDate = DateTime.Today; }
        private string GetT() => (cmbT.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "T1";

        private void CreateClick(object s, RoutedEventArgs e)
        { try { _svc.Create(_empId, GetT(), dpD.SelectedDate ?? DateTime.Today, txtN.Text); DialogResult = true; Close(); } catch (Exception ex) { txtE.Text = ex.Message; } }

        private void PdfClick(object s, RoutedEventArgs e)
        {
            try
            {
                var order = _svc.Create(_empId, GetT(), dpD.SelectedDate ?? DateTime.Today, txtN.Text);
                var dlg = new SaveFileDialog { Filter = "PDF|*.pdf", FileName = $"Приказ_{order.OrderNumber}.pdf" };
                if (dlg.ShowDialog() == true) { System.IO.File.WriteAllBytes(dlg.FileName, _svc.GeneratePdf(order.Id)); MessageBox.Show("PDF сохранен"); }
                DialogResult = true; Close();
            }
            catch (Exception ex) { txtE.Text = ex.Message; }
        }

        private void CancelClick(object s, RoutedEventArgs e) => Close();
    }
}