using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using KadryVotumS.Data;
using KadryVotumS.Models;

namespace KadryVotumS.Services
{
    public class OrderService
    {
        public List<Order> GetAll()
        {
            using var db = new AppDbContext();
            return db.Orders.Include(o => o.Employee)
                .OrderByDescending(o => o.OrderDate).ToList();
        }

        public Order Create(int empId, string type, DateTime date, string? note = null)
        {
            using var db = new AppDbContext();
            var cnt = db.Orders.Count(o => o.Type == type) + 1;
            var order = new Order
            {
                EmployeeId = empId, Type = type, OrderDate = date,
                OrderNumber = $"{type}-{cnt:D3}", ContentJson = note
            };
            db.Orders.Add(order);
            db.SaveChanges();
            AuditService.Log($"Создан приказ {order.OrderNumber}", "Orders", order.Id);
            return order;
        }

        // генерация PDF
        public byte[] GeneratePdf(int orderId)
        {
            using var db = new AppDbContext();
            var order = db.Orders
                .Include(o => o.Employee).ThenInclude(e => e!.Department)
                .Include(o => o.Employee).ThenInclude(e => e!.Position)
                .First(o => o.Id == orderId);
            var emp = order.Employee!;

            QuestPDF.Settings.License = LicenseType.Community;
            var tn = order.Type switch
            {
                "T1" => "О ПРИЕМЕ НА РАБОТУ",
                "T5" => "О ПЕРЕВОДЕ",
                "T8" => "ОБ УВОЛЬНЕНИИ",
                _ => "ПРИКАЗ"
            };

            return Document.Create(doc =>
            {
                doc.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.Margin(2, Unit.Centimetre);
                    page.Content().Column(col =>
                    {
                        col.Item().AlignCenter().Text("ООО \u00abВотум-С\u00bb").Bold().FontSize(16);
                        col.Item().PaddingTop(10).AlignCenter().Text($"ПРИКАЗ {tn}").Bold().FontSize(13);
                        col.Item().AlignCenter().Text($"N {order.OrderNumber} от {order.OrderDate:dd.MM.yyyy}").FontSize(11);
                        col.Item().PaddingTop(25);
                        col.Item().Text($"ФИО: {emp.FullName}").FontSize(12);
                        col.Item().Text($"Должность: {emp.Position?.Title}").FontSize(12);
                        col.Item().Text($"Подразделение: {emp.Department?.Name}").FontSize(12);
                        if (order.Type == "T1")
                        {
                            col.Item().Text($"Оклад: {emp.Position?.Salary:N0} руб.").FontSize(12);
                            col.Item().Text($"Дата приема: {emp.HireDate:dd.MM.yyyy}").FontSize(12);
                        }
                        if (order.Type == "T8" && emp.FireDate != null)
                            col.Item().Text($"Дата увольнения: {emp.FireDate:dd.MM.yyyy}").FontSize(12);
                        col.Item().PaddingTop(50);
                        col.Item().Text("Руководитель   ____________ / ______________ /").FontSize(11);
                        col.Item().PaddingTop(20);
                        col.Item().Text("Ознакомлен(а)  ____________ / ______________ /").FontSize(11);
                    });
                });
            }).GeneratePdf();
        }
    }
}
