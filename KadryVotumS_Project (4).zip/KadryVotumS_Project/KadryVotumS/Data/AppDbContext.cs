using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using KadryVotumS.Models;

namespace KadryVotumS.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<Department> Departments => Set<Department>();
        public DbSet<Position> Positions => Set<Position>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<Vacation> Vacations => Set<Vacation>();
        public DbSet<AppUser> Users => Set<AppUser>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        protected override void OnConfiguring(DbContextOptionsBuilder opt)
        {
            if (AppConfig.UsePostgres)
                opt.UseNpgsql(AppConfig.PostgresConnection);
            else
                opt.UseSqlite($"Data Source={AppConfig.SqlitePath}");
        }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            // связи
            mb.Entity<Employee>().HasOne(e => e.Department).WithMany(d => d.Employees).HasForeignKey(e => e.DepartmentId);
            mb.Entity<Employee>().HasOne(e => e.Position).WithMany(p => p.Employees).HasForeignKey(e => e.PositionId);
            mb.Entity<Order>().HasOne(o => o.Employee).WithMany(e => e.Orders).HasForeignKey(o => o.EmployeeId);
            mb.Entity<Vacation>().HasOne(v => v.Employee).WithMany(e => e.Vacations).HasForeignKey(v => v.EmployeeId);

            // начальные данные
            var salt = "VotumS_Salt_2026";
            var hash = Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes("admin123" + salt)));

            mb.Entity<AppUser>().HasData(new AppUser
            {
                Id = 1, Email = "admin@votum-s.ru", PasswordHash = hash,
                Role = "admin", DisplayName = "Администратор", IsActive = true
            });

            mb.Entity<Department>().HasData(
                new Department { Id = 1, Name = "Правовой отдел" },
                new Department { Id = 2, Name = "Бухгалтерский отдел" },
                new Department { Id = 3, Name = "Отдел консалтинга" },
                new Department { Id = 4, Name = "Отдел кадров" }
            );

            mb.Entity<Position>().HasData(
                new Position { Id = 1, Title = "Юрист", Salary = 60000 },
                new Position { Id = 2, Title = "Бухгалтер", Salary = 50000 },
                new Position { Id = 3, Title = "Консультант", Salary = 55000 },
                new Position { Id = 4, Title = "Кадровый специалист", Salary = 45000 },
                new Position { Id = 5, Title = "Руководитель отдела", Salary = 80000 }
            );
        }
    }

    // настройки приложения
    public static class AppConfig
    {
        public static bool UsePostgres { get; set; } = false;
        public static string PostgresConnection { get; set; } = "Host=localhost;Port=5432;Database=kadry_db;Username=postgres;Password=postgres";
        public static string SqlitePath { get; set; } = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "kadry.db");

        // пробуем подключиться к postgres, если не получилось - sqlite
        public static void AutoDetect()
        {
            try
            {
                using var conn = new Npgsql.NpgsqlConnection(PostgresConnection);
                conn.Open();
                conn.Close();
                UsePostgres = true;
            }
            catch
            {
                UsePostgres = false;
            }
        }
    }
}
