using System;
using System.Windows;
using KadryVotumS.Data;
using Serilog;

namespace KadryVotumS
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("logs/kadry-.log", rollingInterval: RollingInterval.Day)
                .CreateLogger();
            Log.Information("Запуск приложения");

            // пробуем PostgreSQL, если нет - SQLite
            AppConfig.AutoDetect();
            Log.Information(AppConfig.UsePostgres ? "Режим: PostgreSQL" : "Режим: SQLite");

            try
            {
                using var db = new AppDbContext();
                db.Database.EnsureCreated();
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Ошибка БД");
                MessageBox.Show($"Ошибка подключения к БД:\n{ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            Log.Information("Завершение");
            Log.CloseAndFlush();
            base.OnExit(e);
        }
    }
}