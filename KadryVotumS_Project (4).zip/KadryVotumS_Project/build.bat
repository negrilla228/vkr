@echo off
echo Сборка КадрыВотумС...
echo.

echo [1/3] Восстановление пакетов...
dotnet restore KadryVotumS\KadryVotumS.csproj

echo [2/3] Сборка...
dotnet build KadryVotumS\KadryVotumS.csproj -c Release --no-restore

echo [3/3] Публикация exe...
dotnet publish KadryVotumS\KadryVotumS.csproj -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true -o publish

echo.
echo ГОТОВО! exe в папке publish\
echo Запуск: publish\KadryVotumS.exe
echo Логин: admin@votum-s.ru / admin123
pause
