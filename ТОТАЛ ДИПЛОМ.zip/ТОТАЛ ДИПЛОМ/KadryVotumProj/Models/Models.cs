using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace KadryVotumS.Models
{
    public class Employee
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string LastName { get; set; } = "";

        [Required, MaxLength(100)]
        public string FirstName { get; set; } = "";

        [MaxLength(100)]
        public string? MiddleName { get; set; }

        public DateTime BirthDate { get; set; }

        [MaxLength(20)]
        public string? Passport { get; set; }

        [MaxLength(14)]
        public string? Snils { get; set; }

        [MaxLength(12)]
        public string? Inn { get; set; }

        [MaxLength(20)]
        public string? Phone { get; set; }

        [MaxLength(200)]
        public string? Email { get; set; }

        public int DepartmentId { get; set; }
        public Department? Department { get; set; }

        public int PositionId { get; set; }
        public Position? Position { get; set; }

        public DateTime HireDate { get; set; }
        public DateTime? FireDate { get; set; }

        [MaxLength(20)]
        public string Status { get; set; } = "Работает";

        [MaxLength(10)]
        public string? TabNumber { get; set; }

        public List<Order> Orders { get; set; } = new();
        public List<Vacation> Vacations { get; set; } = new();

        [NotMapped]
        public string FullName => $"{LastName} {FirstName} {MiddleName}".TrimEnd();
    }

    public class Department
    {
        public int Id { get; set; }
        [Required, MaxLength(200)]
        public string Name { get; set; } = "";
        public int? HeadId { get; set; }
        public List<Employee> Employees { get; set; } = new();
    }

    public class Position
    {
        public int Id { get; set; }
        [Required, MaxLength(200)]
        public string Title { get; set; } = "";
        [Column(TypeName = "decimal(10,2)")]
        public decimal Salary { get; set; }
        public List<Employee> Employees { get; set; } = new();
    }

    public class Order
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public Employee? Employee { get; set; }
        [MaxLength(10)]
        public string Type { get; set; } = "T1";
        public DateTime OrderDate { get; set; }
        [MaxLength(20)]
        public string? OrderNumber { get; set; }
        [MaxLength(2000)]
        public string? ContentJson { get; set; }
        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }

    public class Vacation
    {
        public int Id { get; set; }
        public int EmployeeId { get; set; }
        public Employee? Employee { get; set; }
        public DateTime StartDate { get; set; }
        public DateTime EndDate { get; set; }
        [MaxLength(50)]
        public string Type { get; set; } = "Ежегодный оплачиваемый";
        [NotMapped]
        public int Days => (EndDate - StartDate).Days + 1;
    }

    public class AppUser
    {
        public int Id { get; set; }
        [Required, MaxLength(200)]
        public string Email { get; set; } = "";
        public string PasswordHash { get; set; } = "";
        [MaxLength(20)]
        public string Role { get; set; } = "hr";
        public bool IsActive { get; set; } = true;
        [MaxLength(200)]
        public string? DisplayName { get; set; }
    }

    public class AuditLog
    {
        public int Id { get; set; }
        public DateTime Timestamp { get; set; } = DateTime.Now;
        [MaxLength(200)]
        public string? UserEmail { get; set; }
        [MaxLength(50)]
        public string Action { get; set; } = "";
        [MaxLength(100)]
        public string? TableName { get; set; }
        public int? RecordId { get; set; }
        [MaxLength(1000)]
        public string? Details { get; set; }
    }
}
