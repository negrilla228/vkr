@echo off
echo ============================================
echo   Сборка КадрыВотумС - exe для Windows 10
echo ============================================
echo.

echo [1/3] Восстановление пакетов...
dotnet restore
if %errorlevel% neq 0 (
    echo ОШИБКА: не удалось восстановить пакеты
    pause
    exit /b 1
)

echo.
echo [2/3] Сборка проекта...
dotnet build -c Release
if %errorlevel% neq 0 (
    echo ОШИБКА: не удалось собрать проект
    pause
    exit /b 1
)

echo.
echo [3/3] Публикация как самодостаточный exe...
dotnet publish -c Release -r win-x64 --self-contained true -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -o .\publish
if %errorlevel% neq 0 (
    echo ОШИБКА: не удалось опубликовать
    pause
    exit /b 1
)

echo.
echo ============================================
echo   ГОТОВО!
echo   Файл: publish\KadryVotumS.exe
echo   Просто скопируй папку publish на флешку
echo   и запусти KadryVotumS.exe
echo ============================================
echo.
echo Логин: admin@votum-s.ru
echo Пароль: admin123
echo.
pause
