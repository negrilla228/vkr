using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Data;

namespace KadryVotumS.Views
{
    public partial class SettingsPage : Page
    {
        public SettingsPage() { InitializeComponent(); txtConn.Text = AppConfig.PostgresConnection; chkPg.IsChecked = AppConfig.UsePostgres; }
        private void SaveClick(object s, RoutedEventArgs e)
        { AppConfig.PostgresConnection = txtConn.Text.Trim(); AppConfig.UsePostgres = chkPg.IsChecked == true; txtR.Text = "Сохранено. Перезапустите приложение."; }
    }
}