using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class VacationsPage : Page
    {
        public VacationsPage() { InitializeComponent(); Load(); }
        private void Load() { dg.ItemsSource = new VacationService().GetAll(); }
        private void AddClick(object s, RoutedEventArgs e) { if (new AddVacationWindow().ShowDialog() == true) Load(); }
    }
}