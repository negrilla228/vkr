using System.Linq;
using System.Windows.Controls;
using KadryVotumS.Data;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class DashboardPage : Page
    {
        public DashboardPage()
        {
            InitializeComponent();
            var s = new EmployeeService().GetStats();
            t1.Text = s.total.ToString(); t2.Text = s.hired.ToString();
            t3.Text = s.onVac.ToString(); t4.Text = s.fired.ToString();
            using var db = new AppDbContext();
            dgAudit.ItemsSource = db.AuditLogs.OrderByDescending(a => a.Timestamp).Take(20).ToList();
        }
    }
}