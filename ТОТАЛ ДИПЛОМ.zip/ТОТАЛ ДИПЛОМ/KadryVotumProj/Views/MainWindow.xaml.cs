using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            txtUser.Text = AuthService.CurrentUser?.DisplayName ?? AuthService.CurrentUser?.Email;
            btnUsers.Visibility = AuthService.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            btnSet.Visibility = AuthService.IsAdmin ? Visibility.Visible : Visibility.Collapsed;
            MainFrame.Navigate(new DashboardPage());
        }

        private void Nav(object s, RoutedEventArgs e)
        {
            var tag = (s as Button)?.Tag?.ToString();
            Page? p = tag switch
            {
                "Dash" => new DashboardPage(), "Emp" => new EmployeesPage(),
                "Ord" => new OrdersPage(), "Vac" => new VacationsPage(),
                "Staff" => new StaffingPage(), "Rep" => new ReportsPage(),
                "Audit" => new AuditPage(), "Users" => new UsersPage(),
                "Set" => new SettingsPage(), _ => null
            };
            if (p != null) MainFrame.Navigate(p);
        }

        private void Logout(object s, RoutedEventArgs e)
        { AuthService.Logout(); new LoginWindow().Show(); Close(); }
    }
}