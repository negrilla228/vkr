using System;
using System.Windows;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class EmployeeEditWindow : Window
    {
        private readonly Employee? _ex;
        private readonly EmployeeService _svc = new();

        public EmployeeEditWindow(Employee? emp = null)
        {
            InitializeComponent();
            var ss = new StaffingService();
            fDept.ItemsSource = ss.GetDepartments();
            fPos.ItemsSource = ss.GetPositions();
            fHire.SelectedDate = DateTime.Today;

            if (emp != null)
            {
                _ex = emp; Title = "Редактирование: " + emp.FullName;
                fLast.Text = emp.LastName; fFirst.Text = emp.FirstName; fMid.Text = emp.MiddleName;
                fBirth.SelectedDate = emp.BirthDate; fPass.Text = emp.Passport;
                fSnils.Text = emp.Snils; fInn.Text = emp.Inn; fPhone.Text = emp.Phone;
                fDept.SelectedValue = emp.DepartmentId; fPos.SelectedValue = emp.PositionId;
                fHire.SelectedDate = emp.HireDate;
            }
        }

        private void Save(object s, RoutedEventArgs e)
        {
            // валидация по законодательству РФ
            var (ok, error) = ValidationService.ValidateEmployee(
                fLast.Text?.Trim() ?? "", fFirst.Text?.Trim() ?? "", fMid.Text?.Trim(),
                fBirth.SelectedDate, fPass.Text?.Trim(), fSnils.Text?.Trim(), fInn.Text?.Trim(),
                fPhone.Text?.Trim(), fHire.SelectedDate,
                fDept.SelectedValue is int d ? d : 0,
                fPos.SelectedValue is int p ? p : 0
            );

            if (!ok)
            {
                txtErr.Text = error;
                return;
            }

            try
            {
                var emp = _ex ?? new Employee();
                emp.LastName = fLast.Text.Trim();
                emp.FirstName = fFirst.Text.Trim();
                emp.MiddleName = string.IsNullOrWhiteSpace(fMid.Text) ? null : fMid.Text.Trim();
                emp.BirthDate = fBirth.SelectedDate!.Value;
                emp.Passport = string.IsNullOrWhiteSpace(fPass.Text) ? null : fPass.Text.Trim();
                emp.Snils = string.IsNullOrWhiteSpace(fSnils.Text) ? null : fSnils.Text.Trim();
                emp.Inn = string.IsNullOrWhiteSpace(fInn.Text) ? null : fInn.Text.Trim();
                emp.Phone = string.IsNullOrWhiteSpace(fPhone.Text) ? null : fPhone.Text.Trim();
                emp.DepartmentId = (int)fDept.SelectedValue;
                emp.PositionId = (int)fPos.SelectedValue;
                emp.HireDate = fHire.SelectedDate!.Value;

                if (_ex != null) _svc.Update(emp); else _svc.Add(emp);
                DialogResult = true; Close();
            }
            catch (Exception ex)
            {
                // если ошибка уникальности из БД
                var msg = ex.InnerException?.Message ?? ex.Message;
                if (msg.Contains("unique", StringComparison.OrdinalIgnoreCase) ||
                    msg.Contains("duplicate", StringComparison.OrdinalIgnoreCase))
                {
                    if (msg.Contains("Passport", StringComparison.OrdinalIgnoreCase))
                        txtErr.Text = "Сотрудник с таким паспортом уже существует в базе";
                    else if (msg.Contains("Snils", StringComparison.OrdinalIgnoreCase))
                        txtErr.Text = "Сотрудник с таким СНИЛС уже существует в базе";
                    else if (msg.Contains("Inn", StringComparison.OrdinalIgnoreCase))
                        txtErr.Text = "Сотрудник с таким ИНН уже существует в базе";
                    else
                        txtErr.Text = "Запись с такими данными уже существует";
                }
                else
                    txtErr.Text = msg;
            }
        }

        private void Cancel(object s, RoutedEventArgs e) => Close();
    }
}
