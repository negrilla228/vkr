using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class StaffingPage : Page
    {
        private readonly StaffingService _s = new();
        public StaffingPage() { InitializeComponent(); Load(); }
        private void Load() { dgD.ItemsSource = _s.GetDepartments(); dgP.ItemsSource = _s.GetPositions(); }
        private void AddD(object s, RoutedEventArgs e) { var n=Microsoft.VisualBasic.Interaction.InputBox("Название:","Новый отдел"); if(!string.IsNullOrWhiteSpace(n)){_s.AddDepartment(n);Load();} }
        private void AddP(object s, RoutedEventArgs e) { var t=Microsoft.VisualBasic.Interaction.InputBox("Должность:","Новая должность"); if(string.IsNullOrWhiteSpace(t))return; var sv=Microsoft.VisualBasic.Interaction.InputBox("Оклад:","Оклад","50000"); if(decimal.TryParse(sv,out var sal)){_s.AddPosition(t,sal);Load();} }
    }
}