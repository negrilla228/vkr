using System;
using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;
using Microsoft.Win32;

namespace KadryVotumS.Views
{
    public partial class CreateOrderWindow : Window
    {
        private readonly int _empId;
        private readonly OrderService _svc = new();

        public CreateOrderWindow(int empId)
        {
            InitializeComponent();
            _empId = empId;
            dpD.SelectedDate = DateTime.Today;
            dpFire.SelectedDate = DateTime.Today.AddDays(14); // 14 дней отработки по ст. 80 ТК РФ
        }

        private string GetType() => (cmbT.SelectedItem as ComboBoxItem)?.Tag?.ToString() ?? "T1";

        private void TypeChanged(object s, SelectionChangedEventArgs e)
        {
            if (pnlFire == null || btnResign == null) return;
            var isT8 = GetType() == "T8";
            pnlFire.Visibility = isT8 ? Visibility.Visible : Visibility.Collapsed;
            btnResign.Visibility = isT8 ? Visibility.Visible : Visibility.Collapsed;
        }

        private string? GetContent()
        {
            if (GetType() == "T8")
            {
                var reason = (cmbReason.SelectedItem as ComboBoxItem)?.Content?.ToString();
                return reason;
            }
            return string.IsNullOrWhiteSpace(txtN.Text) ? null : txtN.Text;
        }

        private bool Validate()
        {
            if (GetType() == "T8")
            {
                using var db = new Data.AppDbContext();
                var emp = db.Employees.Find(_empId);
                if (emp == null) { txtE.Text = "Сотрудник не найден"; return false; }

                var (ok, err) = ValidationService.ValidateFireDate(dpFire.SelectedDate, emp.HireDate);
                if (!ok) { txtE.Text = err; return false; }
            }
            return true;
        }

        private void CreateClick(object s, RoutedEventArgs e)
        {
            if (!Validate()) return;
            try
            {
                if (GetType() == "T8")
                {
                    // помечаем сотрудника как уволенного
                    using var db = new Data.AppDbContext();
                    var emp = db.Employees.Find(_empId);
                    if (emp != null) { emp.Status = "Уволен"; emp.FireDate = dpFire.SelectedDate; db.SaveChanges(); }
                }
                _svc.Create(_empId, GetType(), dpD.SelectedDate ?? DateTime.Today, GetContent());
                DialogResult = true; Close();
            }
            catch (Exception ex) { txtE.Text = ex.InnerException?.Message ?? ex.Message; }
        }

        private void PdfClick(object s, RoutedEventArgs e)
        {
            if (!Validate()) return;
            try
            {
                if (GetType() == "T8")
                {
                    using var db = new Data.AppDbContext();
                    var emp = db.Employees.Find(_empId);
                    if (emp != null) { emp.Status = "Уволен"; emp.FireDate = dpFire.SelectedDate; db.SaveChanges(); }
                }
                var order = _svc.Create(_empId, GetType(), dpD.SelectedDate ?? DateTime.Today, GetContent());
                var dlg = new SaveFileDialog { Filter = "PDF|*.pdf", FileName = $"Приказ_{GetType()}_{order.OrderNumber}.pdf" };
                if (dlg.ShowDialog() == true)
                {
                    System.IO.File.WriteAllBytes(dlg.FileName, _svc.GeneratePdf(order.Id));
                    MessageBox.Show($"Приказ сохранен:\n{dlg.FileName}", "Готово");
                }
                DialogResult = true; Close();
            }
            catch (Exception ex) { txtE.Text = ex.InnerException?.Message ?? ex.Message; }
        }

        // генерация заявления об увольнении
        private void ResignClick(object s, RoutedEventArgs e)
        {
            if (dpFire.SelectedDate == null) { txtE.Text = "Укажите дату увольнения"; return; }
            try
            {
                var dlg = new SaveFileDialog { Filter = "PDF|*.pdf", FileName = "Заявление_об_увольнении.pdf" };
                if (dlg.ShowDialog() == true)
                {
                    var bytes = _svc.GenerateResignationLetter(_empId, dpFire.SelectedDate.Value);
                    System.IO.File.WriteAllBytes(dlg.FileName, bytes);
                    MessageBox.Show($"Заявление сохранено:\n{dlg.FileName}", "Готово");
                }
            }
            catch (Exception ex) { txtE.Text = ex.InnerException?.Message ?? ex.Message; }
        }

        private void CancelClick(object s, RoutedEventArgs e) => Close();
    }
}