using System.Windows;
using System.Windows.Input;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class LoginWindow : Window
    {
        private int _attempts;
        public LoginWindow() { InitializeComponent(); txtEmail.Focus(); }

        private void PassKeyDown(object s, KeyEventArgs e) { if (e.Key == Key.Enter) LoginClick(s, e); }

        private void LoginClick(object s, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtEmail.Text) || string.IsNullOrEmpty(txtPass.Password))
            { txtError.Text = "Введите email и пароль"; return; }
            if (_attempts >= 5) { txtError.Text = "Слишком много попыток"; return; }

            if (AuthService.Login(txtEmail.Text.Trim(), txtPass.Password))
            { new MainWindow().Show(); Close(); }
            else { _attempts++; txtError.Text = "Неверный email или пароль"; }
        }
    }
}