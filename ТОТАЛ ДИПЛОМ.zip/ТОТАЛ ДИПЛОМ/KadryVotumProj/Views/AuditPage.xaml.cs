using System.Linq;
using System.Windows.Controls;
using KadryVotumS.Data;

namespace KadryVotumS.Views
{
    public partial class AuditPage : Page
    { public AuditPage() { InitializeComponent(); using var db = new AppDbContext(); dg.ItemsSource = db.AuditLogs.OrderByDescending(a=>a.Timestamp).Take(200).ToList(); } }
}