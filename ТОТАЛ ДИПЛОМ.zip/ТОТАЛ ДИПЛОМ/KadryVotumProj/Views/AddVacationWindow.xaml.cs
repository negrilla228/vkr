using System;
using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class AddVacationWindow : Window
    {
        public AddVacationWindow()
        {
            InitializeComponent();
            cmbE.ItemsSource = new EmployeeService().GetAll();
            cmbE.SelectionChanged += (s, e) =>
            {
                if (cmbE.SelectedValue is int id)
                    txtBal.Text = $"Остаток отпускных дней: {new EmployeeService().GetVacationBalance(id)}";
            };
        }

        private void SaveClick(object s, RoutedEventArgs e)
        {
            if (cmbE.SelectedValue == null) { txtE.Text = "Выберите сотрудника"; return; }
            if (dp1.SelectedDate == null) { txtE.Text = "Укажите дату начала"; return; }
            if (dp2.SelectedDate == null) { txtE.Text = "Укажите дату окончания"; return; }
            if (dp2.SelectedDate < dp1.SelectedDate) { txtE.Text = "Дата окончания не может быть раньше даты начала"; return; }

            var days = (dp2.SelectedDate.Value - dp1.SelectedDate.Value).Days + 1;
            if (days > 28 * 2)
            {
                txtE.Text = "Период отпуска не может превышать 56 календарных дней";
                return;
            }

            if (days < 1) { txtE.Text = "Минимальная продолжительность отпуска - 1 день"; return; }

            // по ТК РФ одна часть отпуска не менее 14 дней
            var type = (cmbT.SelectedItem as ComboBoxItem)?.Content?.ToString() ?? "Ежегодный оплачиваемый";

            try
            {
                new VacationService().Add(new Vacation
                {
                    EmployeeId = (int)cmbE.SelectedValue,
                    StartDate = dp1.SelectedDate.Value,
                    EndDate = dp2.SelectedDate.Value,
                    Type = type
                });
                DialogResult = true; Close();
            }
            catch (Exception ex) { txtE.Text = ex.Message; }
        }

        private void CancelClick(object s, RoutedEventArgs e) => Close();
    }
}