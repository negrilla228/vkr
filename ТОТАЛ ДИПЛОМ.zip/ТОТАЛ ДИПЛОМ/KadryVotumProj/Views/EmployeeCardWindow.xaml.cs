using System;
using System.Windows;
using KadryVotumS.Models;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class EmployeeCardWindow : Window
    {
        private readonly int _id;
        private Employee? _emp;
        public EmployeeCardWindow(int id) { InitializeComponent(); _id = id; Load(); }

        private void Load()
        {
            _emp = new EmployeeService().GetById(_id);
            if (_emp == null) { Close(); return; }
            txtName.Text = _emp.FullName;
            txtInfo.Text = $"{_emp.Position?.Title}, {_emp.Department?.Name} | {_emp.Status}";
            f1.Text = $"Дата рождения: {_emp.BirthDate:dd.MM.yyyy}";
            f2.Text = $"Табельный N: {_emp.TabNumber}";
            f3.Text = $"Паспорт: {_emp.Passport}"; f4.Text = $"СНИЛС: {_emp.Snils}";
            f5.Text = $"ИНН: {_emp.Inn}"; f6.Text = $"Телефон: {_emp.Phone}";
            f7.Text = $"Дата приема: {_emp.HireDate:dd.MM.yyyy}";
            f8.Text = $"Остаток отпуска: {new EmployeeService().GetVacationBalance(_id)} дней";
            var d = (DateTime.Now - _emp.HireDate).Days;
            f9.Text = $"Стаж: {d/365} лет {d%365/30} мес.";
            dgO.ItemsSource = _emp.Orders; dgV.ItemsSource = _emp.Vacations;
        }

        private void EditClick(object s, RoutedEventArgs e) { if (_emp != null && new EmployeeEditWindow(_emp).ShowDialog() == true) Load(); }
        private void OrderClick(object s, RoutedEventArgs e) { if (_emp != null && new CreateOrderWindow(_id).ShowDialog() == true) Load(); }
    }
}