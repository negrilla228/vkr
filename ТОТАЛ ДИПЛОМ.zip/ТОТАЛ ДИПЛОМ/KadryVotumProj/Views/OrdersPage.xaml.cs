using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using KadryVotumS.Models;
using KadryVotumS.Services;
using Microsoft.Win32;

namespace KadryVotumS.Views
{
    public partial class OrdersPage : Page
    {
        public OrdersPage() { InitializeComponent(); dg.ItemsSource = new OrderService().GetAll(); }
        private void PdfClick(object s, MouseButtonEventArgs e)
        {
            if (dg.SelectedItem is Order o)
            { try { var dlg = new SaveFileDialog{Filter="PDF|*.pdf",FileName=$"Приказ_{o.OrderNumber}.pdf"}; if(dlg.ShowDialog()==true){System.IO.File.WriteAllBytes(dlg.FileName,new OrderService().GeneratePdf(o.Id));MessageBox.Show("PDF сохранен");}} catch(Exception ex){MessageBox.Show(ex.Message);} }
        }
    }
}