using System;
using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;
using Microsoft.Win32;

namespace KadryVotumS.Views
{
    public partial class ReportsPage : Page
    {
        public ReportsPage() { InitializeComponent(); }
        private void ExcelClick(object s, RoutedEventArgs e)
        {
            var dlg = new SaveFileDialog{Filter="Excel|*.xlsx",FileName=$"Сотрудники_{DateTime.Now:yyyyMMdd}.xlsx"};
            if(dlg.ShowDialog()==true){ try{new ReportService().ExportToExcel(dlg.FileName);txtR.Text="Сохранено: "+dlg.FileName;}catch(Exception ex){txtR.Text=ex.Message;txtR.Foreground=System.Windows.Media.Brushes.Red;}}
        }
    }
}