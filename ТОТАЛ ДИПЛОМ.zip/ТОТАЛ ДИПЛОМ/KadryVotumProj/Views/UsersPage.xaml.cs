using System.Windows;
using System.Windows.Controls;
using KadryVotumS.Services;

namespace KadryVotumS.Views
{
    public partial class UsersPage : Page
    {
        private readonly UserService _s = new();
        public UsersPage() { InitializeComponent(); Load(); }
        private void Load() { dg.ItemsSource = _s.GetAll(); }
        private void AddClick(object s, RoutedEventArgs e)
        {
            var em = Microsoft.VisualBasic.Interaction.InputBox("Email:","Новый пользователь"); if(string.IsNullOrWhiteSpace(em))return;
            var pw = Microsoft.VisualBasic.Interaction.InputBox("Пароль:","Пароль"); if(string.IsNullOrWhiteSpace(pw))return;
            var rl = Microsoft.VisualBasic.Interaction.InputBox("Роль (admin/hr/manager):","Роль","hr");
            _s.Add(em,pw,rl); Load();
        }
    }
}