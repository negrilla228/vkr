using System;
using System.Windows;
using KadryVotumS.Data;
using Serilog;

namespace KadryVotumS
{
    public partial class App : Application
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            base.OnStartup(e);
            Log.Logger = new LoggerConfiguration()
                .WriteTo.File("logs/kadry-.log", rollingInterval: RollingInterval.Day)
                .CreateLogger();
            Log.Information("Запуск приложения");

            AppConfig.AutoDetect();
            Log.Information(AppConfig.UsePostgres ? "Режим: PostgreSQL" : "Режим: SQLite");

            try
            {
                using var db = new AppDbContext();
                // пересоздаем БД если нужно (для демонстрации с сидами)
                db.Database.EnsureCreated();
                Log.Information("База данных готова");
            }
            catch (Exception ex)
            {
                Log.Error(ex, "Ошибка БД");
                MessageBox.Show(
                    $"Не удалось подключиться к БД:\n{ex.Message}\n\nПрограмма запустится в режиме SQLite.",
                    "Внимание", MessageBoxButton.OK, MessageBoxImage.Warning);

                // переключаемся на SQLite если postgres не работает
                AppConfig.UsePostgres = false;
                try
                {
                    using var db2 = new AppDbContext();
                    db2.Database.EnsureCreated();
                }
                catch (Exception ex2)
                {
                    MessageBox.Show($"Критическая ошибка БД:\n{ex2.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    Shutdown();
                }
            }
        }

        protected override void OnExit(ExitEventArgs e)
        {
            Log.Information("Завершение");
            Log.CloseAndFlush();
            base.OnExit(e);
        }
    }
}
