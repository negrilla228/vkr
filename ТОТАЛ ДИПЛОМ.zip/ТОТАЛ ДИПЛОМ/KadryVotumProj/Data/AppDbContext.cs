using System;
using System.IO;
using System.Security.Cryptography;
using System.Text;
using Microsoft.EntityFrameworkCore;
using KadryVotumS.Models;

namespace KadryVotumS.Data
{
    public class AppDbContext : DbContext
    {
        public DbSet<Employee> Employees => Set<Employee>();
        public DbSet<Department> Departments => Set<Department>();
        public DbSet<Position> Positions => Set<Position>();
        public DbSet<Order> Orders => Set<Order>();
        public DbSet<Vacation> Vacations => Set<Vacation>();
        public DbSet<AppUser> Users => Set<AppUser>();
        public DbSet<AuditLog> AuditLogs => Set<AuditLog>();

        protected override void OnConfiguring(DbContextOptionsBuilder opt)
        {
            if (AppConfig.UsePostgres)
                opt.UseNpgsql(AppConfig.PostgresConnection);
            else
                opt.UseSqlite($"Data Source={AppConfig.SqlitePath}");
        }

        protected override void OnModelCreating(ModelBuilder mb)
        {
            mb.Entity<Employee>().HasOne(e => e.Department).WithMany(d => d.Employees).HasForeignKey(e => e.DepartmentId);
            mb.Entity<Employee>().HasOne(e => e.Position).WithMany(p => p.Employees).HasForeignKey(e => e.PositionId);
            mb.Entity<Order>().HasOne(o => o.Employee).WithMany(e => e.Orders).HasForeignKey(o => o.EmployeeId);
            mb.Entity<Vacation>().HasOne(v => v.Employee).WithMany(e => e.Vacations).HasForeignKey(v => v.EmployeeId);

            var salt = "VotumS_Salt_2026";
            string H(string p) => Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(p + salt)));

            // ===== ПОЛЬЗОВАТЕЛИ =====
            mb.Entity<AppUser>().HasData(
                new AppUser { Id = 1, Email = "admin@votum-s.ru", PasswordHash = H("admin123"), Role = "admin", DisplayName = "Администратор", IsActive = true },
                new AppUser { Id = 2, Email = "kadry@votum-s.ru", PasswordHash = H("kadry123"), Role = "hr", DisplayName = "Смирнова О.А.", IsActive = true },
                new AppUser { Id = 3, Email = "boss@votum-s.ru", PasswordHash = H("boss123"), Role = "manager", DisplayName = "Директор", IsActive = true }
            );

            // ===== ОТДЕЛЫ =====
            mb.Entity<Department>().HasData(
                new Department { Id = 1, Name = "Правовой отдел" },
                new Department { Id = 2, Name = "Бухгалтерский отдел" },
                new Department { Id = 3, Name = "Отдел консалтинга" },
                new Department { Id = 4, Name = "Отдел кадров" },
                new Department { Id = 5, Name = "Отдел налогового консультирования" },
                new Department { Id = 6, Name = "Административный отдел" }
            );

            // ===== ДОЛЖНОСТИ =====
            mb.Entity<Position>().HasData(
                new Position { Id = 1, Title = "Юрист", Salary = 60000 },
                new Position { Id = 2, Title = "Бухгалтер", Salary = 50000 },
                new Position { Id = 3, Title = "Консультант", Salary = 55000 },
                new Position { Id = 4, Title = "Кадровый специалист", Salary = 45000 },
                new Position { Id = 5, Title = "Руководитель отдела", Salary = 80000 },
                new Position { Id = 6, Title = "Старший юрист", Salary = 75000 },
                new Position { Id = 7, Title = "Главный бухгалтер", Salary = 85000 },
                new Position { Id = 8, Title = "Налоговый консультант", Salary = 65000 },
                new Position { Id = 9, Title = "Секретарь", Salary = 35000 },
                new Position { Id = 10, Title = "Помощник юриста", Salary = 40000 },
                new Position { Id = 11, Title = "Стажер", Salary = 25000 },
                new Position { Id = 12, Title = "Генеральный директор", Salary = 150000 }
            );

            // ===== СОТРУДНИКИ (30 человек) =====
            mb.Entity<Employee>().HasData(
                new Employee { Id=1, LastName="Иванова", FirstName="Мария", MiddleName="Петровна", BirthDate=new DateTime(1990,3,15), Passport="2714 556789", Snils="123-456-789 00", Inn="390201234567", Phone="+79114567890", DepartmentId=1, PositionId=6, HireDate=new DateTime(2021,2,1), Status="Работает", TabNumber="0001" },
                new Employee { Id=2, LastName="Петров", FirstName="Алексей", MiddleName="Викторович", BirthDate=new DateTime(1985,7,22), Passport="2710 443322", Snils="234-567-890 11", Inn="390212345678", Phone="+79215678901", DepartmentId=2, PositionId=7, HireDate=new DateTime(2019,5,15), Status="Работает", TabNumber="0002" },
                new Employee { Id=3, LastName="Козлова", FirstName="Елена", MiddleName="Михайловна", BirthDate=new DateTime(1993,11,8), Passport="2716 778899", Snils="345-678-901 22", Inn="390223456789", Phone="+79316789012", DepartmentId=3, PositionId=3, HireDate=new DateTime(2024,9,1), Status="Работает", TabNumber="0003" },
                new Employee { Id=4, LastName="Сидоров", FirstName="Константин", MiddleName="Павлович", BirthDate=new DateTime(1988,1,30), Passport="2712 112233", Snils="456-789-012 33", Inn="390234567890", Phone="+79417890123", DepartmentId=1, PositionId=1, HireDate=new DateTime(2020,3,10), Status="Работает", TabNumber="0004" },
                new Employee { Id=5, LastName="Морозова", FirstName="Анна", MiddleName="Сергеевна", BirthDate=new DateTime(1995,5,14), Passport="2718 334455", Snils="567-890-123 44", Inn="390245678901", Phone="+79518901234", DepartmentId=4, PositionId=4, HireDate=new DateTime(2022,8,22), Status="Работает", TabNumber="0005" },
                new Employee { Id=6, LastName="Николаев", FirstName="Игорь", MiddleName="Степанович", BirthDate=new DateTime(1982,9,3), Passport="2708 998877", Snils="678-901-234 55", Inn="390256789012", Phone="+79619012345", DepartmentId=2, PositionId=2, HireDate=new DateTime(2018,1,15), Status="Работает", TabNumber="0006" },
                new Employee { Id=7, LastName="Федорова", FirstName="Ольга", MiddleName="Андреевна", BirthDate=new DateTime(1991,12,25), Passport="2715 667788", Snils="789-012-345 66", Inn="390267890123", Phone="+79710123456", DepartmentId=1, PositionId=1, HireDate=new DateTime(2023,4,3), Status="Работает", TabNumber="0007" },
                new Employee { Id=8, LastName="Волков", FirstName="Дмитрий", MiddleName="Олегович", BirthDate=new DateTime(1987,4,17), Passport="2711 223344", Snils="890-123-456 77", Inn="390278901234", Phone="+79811234567", DepartmentId=5, PositionId=8, HireDate=new DateTime(2021,7,12), Status="Работает", TabNumber="0008" },
                new Employee { Id=9, LastName="Кузнецова", FirstName="Татьяна", MiddleName="Николаевна", BirthDate=new DateTime(1994,8,9), Passport="2717 445566", Snils="901-234-567 88", Inn="390289012345", Phone="+79912345678", DepartmentId=3, PositionId=3, HireDate=new DateTime(2022,11,1), Status="Работает", TabNumber="0009" },
                new Employee { Id=10, LastName="Смирнов", FirstName="Андрей", MiddleName="Васильевич", BirthDate=new DateTime(1980,2,28), Passport="2706 887766", Snils="012-345-678 99", Inn="390290123456", Phone="+79013456789", DepartmentId=6, PositionId=12, HireDate=new DateTime(2015,6,1), Status="Работает", TabNumber="0010" },
                new Employee { Id=11, LastName="Попова", FirstName="Наталья", MiddleName="Ивановна", BirthDate=new DateTime(1992,6,11), Passport="2716 112244", Snils="111-222-333 44", Inn="390201111111", Phone="+79114561111", DepartmentId=1, PositionId=10, HireDate=new DateTime(2024,1,15), Status="Работает", TabNumber="0011" },
                new Employee { Id=12, LastName="Лебедев", FirstName="Артем", MiddleName="Денисович", BirthDate=new DateTime(1996,10,5), Passport="2719 334411", Snils="222-333-444 55", Inn="390202222222", Phone="+79215672222", DepartmentId=5, PositionId=8, HireDate=new DateTime(2023,3,20), Status="Работает", TabNumber="0012" },
                new Employee { Id=13, LastName="Новикова", FirstName="Екатерина", MiddleName="Алексеевна", BirthDate=new DateTime(1989,3,22), Passport="2713 556633", Snils="333-444-555 66", Inn="390203333333", Phone="+79316783333", DepartmentId=2, PositionId=2, HireDate=new DateTime(2020,9,7), Status="Работает", TabNumber="0013" },
                new Employee { Id=14, LastName="Орлов", FirstName="Максим", MiddleName="Юрьевич", BirthDate=new DateTime(1986,7,18), Passport="2710 778822", Snils="444-555-666 77", Inn="390204444444", Phone="+79417894444", DepartmentId=1, PositionId=6, HireDate=new DateTime(2019,11,11), Status="Работает", TabNumber="0014" },
                new Employee { Id=15, LastName="Белова", FirstName="Светлана", MiddleName="Григорьевна", BirthDate=new DateTime(1997,1,7), Passport="2720 990011", Snils="555-666-777 88", Inn="390205555555", Phone="+79518905555", DepartmentId=3, PositionId=3, HireDate=new DateTime(2024,6,1), Status="Работает", TabNumber="0015" },
                new Employee { Id=16, LastName="Комаров", FirstName="Сергей", MiddleName="Борисович", BirthDate=new DateTime(1983,11,29), Passport="2709 445599", Snils="666-777-888 99", Inn="390206666666", Phone="+79619016666", DepartmentId=6, PositionId=9, HireDate=new DateTime(2017,4,10), Status="Работает", TabNumber="0016" },
                new Employee { Id=17, LastName="Захарова", FirstName="Ирина", MiddleName="Владимировна", BirthDate=new DateTime(1990,5,20), Passport="2714 667744", Snils="777-888-999 00", Inn="390207777777", Phone="+79710127777", DepartmentId=4, PositionId=4, HireDate=new DateTime(2021,10,18), Status="Работает", TabNumber="0017" },
                new Employee { Id=18, LastName="Григорьев", FirstName="Павел", MiddleName="Романович", BirthDate=new DateTime(2000,8,12), Passport="2721 112255", Snils="888-999-000 11", Inn="390208888888", Phone="+79811238888", DepartmentId=1, PositionId=11, HireDate=new DateTime(2025,2,3), Status="Работает", TabNumber="0018" },
                new Employee { Id=19, LastName="Соколова", FirstName="Дарья", MiddleName="Евгеньевна", BirthDate=new DateTime(1993,4,2), Passport="2716 889933", Snils="999-000-111 22", Inn="390209999999", Phone="+79912349999", DepartmentId=5, PositionId=8, HireDate=new DateTime(2022,5,16), Status="Работает", TabNumber="0019" },
                new Employee { Id=20, LastName="Егоров", FirstName="Виталий", MiddleName="Александрович", BirthDate=new DateTime(1984,12,1), Passport="2709 334488", Snils="100-200-300 40", Inn="390210000000", Phone="+79013450000", DepartmentId=2, PositionId=2, HireDate=new DateTime(2016,8,29), Status="Работает", TabNumber="0020" },
                // уволенные
                new Employee { Id=21, LastName="Титов", FirstName="Роман", MiddleName="Геннадьевич", BirthDate=new DateTime(1991,9,14), Passport="2715 990088", Snils="200-300-400 50", Inn="390211000001", Phone="+79114560021", DepartmentId=1, PositionId=1, HireDate=new DateTime(2022,1,10), FireDate=new DateTime(2025,3,15), Status="Уволен", TabNumber="0021" },
                new Employee { Id=22, LastName="Медведева", FirstName="Юлия", MiddleName="Дмитриевна", BirthDate=new DateTime(1998,2,19), Passport="2720 112277", Snils="300-400-500 60", Inn="390212000002", Phone="+79215670022", DepartmentId=3, PositionId=3, HireDate=new DateTime(2023,7,1), FireDate=new DateTime(2024,12,20), Status="Уволен", TabNumber="0022" },
                new Employee { Id=23, LastName="Макаров", FirstName="Олег", MiddleName="Витальевич", BirthDate=new DateTime(1986,6,30), Passport="2710 556644", Snils="400-500-600 70", Inn="390213000003", Phone="+79316780023", DepartmentId=2, PositionId=2, HireDate=new DateTime(2019,3,5), FireDate=new DateTime(2025,1,31), Status="Уволен", TabNumber="0023" }
            );

            // ===== ПРИКАЗЫ =====
            mb.Entity<Order>().HasData(
                new Order { Id=1, EmployeeId=1, Type="T1", OrderDate=new DateTime(2021,2,1), OrderNumber="001", CreatedAt=new DateTime(2021,2,1) },
                new Order { Id=2, EmployeeId=2, Type="T1", OrderDate=new DateTime(2019,5,15), OrderNumber="002", CreatedAt=new DateTime(2019,5,15) },
                new Order { Id=3, EmployeeId=3, Type="T1", OrderDate=new DateTime(2024,9,1), OrderNumber="003", CreatedAt=new DateTime(2024,9,1) },
                new Order { Id=4, EmployeeId=4, Type="T1", OrderDate=new DateTime(2020,3,10), OrderNumber="004", CreatedAt=new DateTime(2020,3,10) },
                new Order { Id=5, EmployeeId=5, Type="T1", OrderDate=new DateTime(2022,8,22), OrderNumber="005", CreatedAt=new DateTime(2022,8,22) },
                new Order { Id=6, EmployeeId=6, Type="T1", OrderDate=new DateTime(2018,1,15), OrderNumber="006", CreatedAt=new DateTime(2018,1,15) },
                new Order { Id=7, EmployeeId=7, Type="T1", OrderDate=new DateTime(2023,4,3), OrderNumber="007", CreatedAt=new DateTime(2023,4,3) },
                new Order { Id=8, EmployeeId=8, Type="T1", OrderDate=new DateTime(2021,7,12), OrderNumber="008", CreatedAt=new DateTime(2021,7,12) },
                new Order { Id=9, EmployeeId=10, Type="T1", OrderDate=new DateTime(2015,6,1), OrderNumber="009", CreatedAt=new DateTime(2015,6,1) },
                // переводы
                new Order { Id=10, EmployeeId=1, Type="T5", OrderDate=new DateTime(2023,6,15), OrderNumber="010", ContentJson="Перевод на должность старшего юриста", CreatedAt=new DateTime(2023,6,15) },
                new Order { Id=11, EmployeeId=6, Type="T5", OrderDate=new DateTime(2022,1,10), OrderNumber="011", ContentJson="Перевод в бухгалтерский отдел", CreatedAt=new DateTime(2022,1,10) },
                // увольнения
                new Order { Id=12, EmployeeId=21, Type="T8", OrderDate=new DateTime(2025,3,15), OrderNumber="012", ContentJson="по инициативе работника (собственное желание), п. 3 ч. 1 ст. 77 ТК РФ", CreatedAt=new DateTime(2025,3,15) },
                new Order { Id=13, EmployeeId=22, Type="T8", OrderDate=new DateTime(2024,12,20), OrderNumber="013", ContentJson="по соглашению сторон, п. 1 ч. 1 ст. 77 ТК РФ", CreatedAt=new DateTime(2024,12,20) },
                new Order { Id=14, EmployeeId=23, Type="T8", OrderDate=new DateTime(2025,1,31), OrderNumber="014", ContentJson="по инициативе работника (собственное желание), п. 3 ч. 1 ст. 77 ТК РФ", CreatedAt=new DateTime(2025,1,31) }
            );

            // ===== ОТПУСКА =====
            mb.Entity<Vacation>().HasData(
                new Vacation { Id=1, EmployeeId=1, StartDate=new DateTime(2024,7,1), EndDate=new DateTime(2024,7,14), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=2, EmployeeId=1, StartDate=new DateTime(2025,1,13), EndDate=new DateTime(2025,1,26), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=3, EmployeeId=2, StartDate=new DateTime(2024,8,5), EndDate=new DateTime(2024,8,18), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=4, EmployeeId=2, StartDate=new DateTime(2025,3,3), EndDate=new DateTime(2025,3,16), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=5, EmployeeId=4, StartDate=new DateTime(2024,6,10), EndDate=new DateTime(2024,7,7), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=6, EmployeeId=5, StartDate=new DateTime(2024,12,23), EndDate=new DateTime(2025,1,5), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=7, EmployeeId=6, StartDate=new DateTime(2024,9,2), EndDate=new DateTime(2024,9,15), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=8, EmployeeId=7, StartDate=new DateTime(2025,2,10), EndDate=new DateTime(2025,2,23), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=9, EmployeeId=8, StartDate=new DateTime(2024,10,14), EndDate=new DateTime(2024,10,27), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=10, EmployeeId=10, StartDate=new DateTime(2024,5,6), EndDate=new DateTime(2024,6,2), Type="Ежегодный оплачиваемый" },
                // больничные
                new Vacation { Id=11, EmployeeId=3, StartDate=new DateTime(2025,2,3), EndDate=new DateTime(2025,2,7), Type="По болезни" },
                new Vacation { Id=12, EmployeeId=13, StartDate=new DateTime(2025,1,20), EndDate=new DateTime(2025,1,24), Type="По болезни" },
                new Vacation { Id=13, EmployeeId=9, StartDate=new DateTime(2024,11,11), EndDate=new DateTime(2024,11,15), Type="По болезни" },
                // учебные
                new Vacation { Id=14, EmployeeId=11, StartDate=new DateTime(2025,1,13), EndDate=new DateTime(2025,2,9), Type="Учебный" },
                new Vacation { Id=15, EmployeeId=18, StartDate=new DateTime(2025,6,1), EndDate=new DateTime(2025,6,28), Type="Учебный" },
                // без сохранения
                new Vacation { Id=16, EmployeeId=16, StartDate=new DateTime(2025,3,10), EndDate=new DateTime(2025,3,14), Type="Без сохранения зарплаты" },
                new Vacation { Id=17, EmployeeId=14, StartDate=new DateTime(2024,12,2), EndDate=new DateTime(2024,12,6), Type="Без сохранения зарплаты" },
                // текущие / будущие отпуска
                new Vacation { Id=18, EmployeeId=4, StartDate=new DateTime(2025,5,19), EndDate=new DateTime(2025,6,1), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=19, EmployeeId=12, StartDate=new DateTime(2025,6,2), EndDate=new DateTime(2025,6,15), Type="Ежегодный оплачиваемый" },
                new Vacation { Id=20, EmployeeId=15, StartDate=new DateTime(2025,7,7), EndDate=new DateTime(2025,7,20), Type="Ежегодный оплачиваемый" }
            );

            // ===== ЖУРНАЛ АУДИТА =====
            mb.Entity<AuditLog>().HasData(
                new AuditLog { Id=1, Timestamp=new DateTime(2025,5,20,9,0,0), UserEmail="admin@votum-s.ru", Action="Вход в систему", TableName="Users", RecordId=1 },
                new AuditLog { Id=2, Timestamp=new DateTime(2025,5,20,9,5,0), UserEmail="admin@votum-s.ru", Action="Добавлен сотрудник", TableName="Employees", RecordId=18, Details="Григорьев Павел Романович" },
                new AuditLog { Id=3, Timestamp=new DateTime(2025,5,20,9,10,0), UserEmail="kadry@votum-s.ru", Action="Вход в систему", TableName="Users", RecordId=2 },
                new AuditLog { Id=4, Timestamp=new DateTime(2025,5,20,9,15,0), UserEmail="kadry@votum-s.ru", Action="Создан приказ T1 N003", TableName="Orders", RecordId=3 },
                new AuditLog { Id=5, Timestamp=new DateTime(2025,5,20,10,30,0), UserEmail="kadry@votum-s.ru", Action="Оформлен отпуск (14 дн.)", TableName="Vacations", RecordId=18, Details="Сидоров К.П." },
                new AuditLog { Id=6, Timestamp=new DateTime(2025,5,21,8,45,0), UserEmail="admin@votum-s.ru", Action="Вход в систему", TableName="Users", RecordId=1 },
                new AuditLog { Id=7, Timestamp=new DateTime(2025,5,21,9,0,0), UserEmail="admin@votum-s.ru", Action="Изменен сотрудник", TableName="Employees", RecordId=7, Details="Федорова О.А. - обновлен телефон" },
                new AuditLog { Id=8, Timestamp=new DateTime(2025,5,21,11,0,0), UserEmail="kadry@votum-s.ru", Action="Экспорт в Excel", Details="Сотрудники_20250521.xlsx" },
                new AuditLog { Id=9, Timestamp=new DateTime(2025,5,22,9,30,0), UserEmail="kadry@votum-s.ru", Action="Уволен сотрудник", TableName="Employees", RecordId=21, Details="Титов Р.Г." },
                new AuditLog { Id=10, Timestamp=new DateTime(2025,5,22,9,35,0), UserEmail="kadry@votum-s.ru", Action="Создан приказ T8 N012", TableName="Orders", RecordId=12 }
            );
        }
    }

    public static class AppConfig
    {
        public static bool UsePostgres { get; set; } = false;
        public static string PostgresConnection { get; set; } = "Host=localhost;Port=5432;Database=kadry_db;Username=postgres;Password=postgres";
        public static string SqlitePath { get; set; } = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "kadry.db");

        public static void AutoDetect()
        {
            try
            {
                using var conn = new Npgsql.NpgsqlConnection(PostgresConnection);
                conn.Open();
                conn.Close();
                UsePostgres = true;
            }
            catch
            {
                UsePostgres = false;
            }
        }
    }
}
