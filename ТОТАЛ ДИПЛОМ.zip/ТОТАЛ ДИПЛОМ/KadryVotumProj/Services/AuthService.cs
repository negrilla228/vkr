using System;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using KadryVotumS.Data;
using KadryVotumS.Models;

namespace KadryVotumS.Services
{
    public static class AuthService
    {
        public static AppUser? CurrentUser { get; private set; }

        public static bool Login(string email, string password)
        {
            using var db = new AppDbContext();
            var user = db.Users.FirstOrDefault(u => u.Email == email && u.IsActive);
            if (user == null) return false;
            if (user.PasswordHash != HashPassword(password)) return false;
            CurrentUser = user;
            AuditService.Log("Вход в систему", "Users", user.Id);
            return true;
        }

        public static void Logout()
        {
            if (CurrentUser != null)
                AuditService.Log("Выход из системы", "Users", CurrentUser.Id);
            CurrentUser = null;
        }

        public static string HashPassword(string password)
        {
            var salt = "VotumS_Salt_2026";
            return Convert.ToBase64String(SHA256.HashData(Encoding.UTF8.GetBytes(password + salt)));
        }

        public static bool IsAdmin => CurrentUser?.Role == "admin";
    }
}
