using System;
using KadryVotumS.Data;
using KadryVotumS.Models;

namespace KadryVotumS.Services
{
    public static class AuditService
    {
        public static void Log(string action, string? table = null, int? recordId = null, string? details = null)
        {
            try
            {
                using var db = new AppDbContext();
                db.AuditLogs.Add(new AuditLog
                {
                    Timestamp = DateTime.Now,
                    UserEmail = AuthService.CurrentUser?.Email ?? "система",
                    Action = action, TableName = table,
                    RecordId = recordId, Details = details
                });
                db.SaveChanges();
            }
            catch { }
        }
    }
}
