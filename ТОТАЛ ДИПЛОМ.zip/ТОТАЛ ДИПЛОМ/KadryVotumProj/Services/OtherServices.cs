using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using KadryVotumS.Data;
using KadryVotumS.Models;

namespace KadryVotumS.Services
{
    public class VacationService
    {
        public List<Vacation> GetAll()
        {
            using var db = new AppDbContext();
            return db.Vacations.Include(v => v.Employee)
                .OrderByDescending(v => v.StartDate).ToList();
        }

        public void Add(Vacation vac)
        {
            var bal = new EmployeeService().GetVacationBalance(vac.EmployeeId);
            var days = (vac.EndDate - vac.StartDate).Days + 1;
            if (vac.Type == "Ежегодный оплачиваемый" && days > bal)
                throw new Exception($"Недостаточно дней. Остаток: {bal}, запрошено: {days}");
            using var db = new AppDbContext();
            db.Vacations.Add(vac);
            db.SaveChanges();
            AuditService.Log($"Оформлен отпуск ({days} дн.)", "Vacations", vac.Id);
        }

        public void Delete(int id)
        {
            using var db = new AppDbContext();
            var v = db.Vacations.Find(id);
            if (v != null) { db.Vacations.Remove(v); db.SaveChanges(); }
        }
    }

    public class StaffingService
    {
        public List<Department> GetDepartments()
        {
            using var db = new AppDbContext();
            return db.Departments.Include(d => d.Employees).OrderBy(d => d.Name).ToList();
        }

        public List<Position> GetPositions()
        {
            using var db = new AppDbContext();
            return db.Positions.OrderBy(p => p.Title).ToList();
        }

        public void AddDepartment(string name)
        {
            using var db = new AppDbContext();
            db.Departments.Add(new Department { Name = name });
            db.SaveChanges();
            AuditService.Log("Добавлен отдел: " + name);
        }

        public void AddPosition(string title, decimal salary)
        {
            using var db = new AppDbContext();
            db.Positions.Add(new Position { Title = title, Salary = salary });
            db.SaveChanges();
            AuditService.Log("Добавлена должность: " + title);
        }
    }

    public class ReportService
    {
        public void ExportToExcel(string path, int? deptId = null)
        {
            var emps = new EmployeeService().GetAll(deptId: deptId);
            using var wb = new ClosedXML.Excel.XLWorkbook();
            var ws = wb.Worksheets.Add("Сотрудники");
            string[] headers = {"Таб.N","ФИО","Должность","Отдел","Дата приема","Статус"};
            for (int i = 0; i < headers.Length; i++)
            {
                ws.Cell(1, i+1).Value = headers[i];
                ws.Cell(1, i+1).Style.Font.Bold = true;
            }
            for (int i = 0; i < emps.Count; i++)
            {
                var e = emps[i];
                ws.Cell(i+2,1).Value = e.TabNumber;
                ws.Cell(i+2,2).Value = e.FullName;
                ws.Cell(i+2,3).Value = e.Position?.Title;
                ws.Cell(i+2,4).Value = e.Department?.Name;
                ws.Cell(i+2,5).Value = e.HireDate.ToString("dd.MM.yyyy");
                ws.Cell(i+2,6).Value = e.Status;
            }
            ws.Columns().AdjustToContents();
            wb.SaveAs(path);
            AuditService.Log("Экспорт в Excel", details: path);
        }
    }

    public class UserService
    {
        public List<AppUser> GetAll()
        {
            using var db = new AppDbContext();
            return db.Users.OrderBy(u => u.Email).ToList();
        }

        public void Add(string email, string pass, string role, string? name = null)
        {
            using var db = new AppDbContext();
            db.Users.Add(new AppUser
            {
                Email = email,
                PasswordHash = AuthService.HashPassword(pass),
                Role = role, DisplayName = name, IsActive = true
            });
            db.SaveChanges();
            AuditService.Log("Создан пользователь: " + email);
        }

        public void Block(int id)
        {
            using var db = new AppDbContext();
            var u = db.Users.Find(id);
            if (u != null) { u.IsActive = false; db.SaveChanges(); }
        }

        public void ResetPassword(int id, string np)
        {
            using var db = new AppDbContext();
            var u = db.Users.Find(id);
            if (u != null) { u.PasswordHash = AuthService.HashPassword(np); db.SaveChanges(); }
        }
    }
}
