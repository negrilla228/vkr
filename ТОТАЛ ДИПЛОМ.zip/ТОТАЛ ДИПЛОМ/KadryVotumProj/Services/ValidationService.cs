using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace KadryVotumS.Services
{
    // валидация кадровых данных по законодательству РФ
    public static class ValidationService
    {
        // проверка СНИЛС (формат XXX-XXX-XXX XX, контрольное число)
        public static (bool ok, string error) ValidateSnils(string? snils)
        {
            if (string.IsNullOrWhiteSpace(snils)) return (true, ""); // необязательное поле

            // убираем все кроме цифр
            var digits = new string(snils.Where(char.IsDigit).ToArray());

            if (digits.Length != 11)
                return (false, "СНИЛС должен содержать 11 цифр (формат: XXX-XXX-XXX XX)");

            // контрольное число - последние 2 цифры
            int control = int.Parse(digits.Substring(9, 2));
            int sum = 0;
            for (int i = 0; i < 9; i++)
                sum += (digits[i] - '0') * (9 - i);

            int check;
            if (sum < 100) check = sum;
            else if (sum == 100 || sum == 101) check = 0;
            else check = sum % 101;
            if (check == 100) check = 0;

            if (check != control)
                return (false, "Некорректное контрольное число СНИЛС");

            return (true, "");
        }

        // проверка ИНН физлица (12 цифр, контрольные числа)
        public static (bool ok, string error) ValidateInn(string? inn)
        {
            if (string.IsNullOrWhiteSpace(inn)) return (true, "");

            var digits = new string(inn.Where(char.IsDigit).ToArray());

            if (digits.Length != 12)
                return (false, "ИНН физического лица должен содержать 12 цифр");

            // коэффициенты для проверки 11-й цифры
            int[] k11 = { 7, 2, 4, 10, 3, 5, 9, 4, 6, 8 };
            int sum11 = 0;
            for (int i = 0; i < 10; i++)
                sum11 += (digits[i] - '0') * k11[i];
            int check11 = sum11 % 11 % 10;

            if (check11 != (digits[10] - '0'))
                return (false, "Некорректная 11-я контрольная цифра ИНН");

            // коэффициенты для проверки 12-й цифры
            int[] k12 = { 3, 7, 2, 4, 10, 3, 5, 9, 4, 6, 8 };
            int sum12 = 0;
            for (int i = 0; i < 11; i++)
                sum12 += (digits[i] - '0') * k12[i];
            int check12 = sum12 % 11 % 10;

            if (check12 != (digits[11] - '0'))
                return (false, "Некорректная 12-я контрольная цифра ИНН");

            return (true, "");
        }

        // проверка паспорта РФ (формат: XXXX XXXXXX или XX XX XXXXXX)
        public static (bool ok, string error) ValidatePassport(string? passport)
        {
            if (string.IsNullOrWhiteSpace(passport)) return (true, "");

            var digits = new string(passport.Where(char.IsDigit).ToArray());

            if (digits.Length != 10)
                return (false, "Паспорт РФ: 10 цифр (серия 4 цифры + номер 6 цифр)");

            // серия: первые 2 цифры - код региона (01-99)
            int region = int.Parse(digits.Substring(0, 2));
            if (region < 1 || region > 99)
                return (false, "Некорректный код региона в серии паспорта");

            return (true, "");
        }

        // проверка ФИО
        public static (bool ok, string error) ValidateFio(string lastName, string firstName, string? middleName)
        {
            if (string.IsNullOrWhiteSpace(lastName))
                return (false, "Фамилия обязательна для заполнения");
            if (string.IsNullOrWhiteSpace(firstName))
                return (false, "Имя обязательно для заполнения");

            if (lastName.Length < 2)
                return (false, "Фамилия слишком короткая");
            if (firstName.Length < 2)
                return (false, "Имя слишком короткое");

            // только буквы, дефис и пробел
            var fioPattern = @"^[а-яА-ЯёЁa-zA-Z\s\-]+$";
            if (!Regex.IsMatch(lastName, fioPattern))
                return (false, "Фамилия содержит недопустимые символы");
            if (!Regex.IsMatch(firstName, fioPattern))
                return (false, "Имя содержит недопустимые символы");
            if (!string.IsNullOrEmpty(middleName) && !Regex.IsMatch(middleName, fioPattern))
                return (false, "Отчество содержит недопустимые символы");

            return (true, "");
        }

        // проверка даты рождения
        public static (bool ok, string error) ValidateBirthDate(DateTime? date)
        {
            if (date == null)
                return (false, "Дата рождения обязательна");

            var age = (DateTime.Now - date.Value).Days / 365;

            if (age < 14)
                return (false, "Возраст работника не может быть менее 14 лет (ст. 63 ТК РФ)");
            if (age > 100)
                return (false, "Проверьте дату рождения - возраст более 100 лет");
            if (date.Value > DateTime.Now)
                return (false, "Дата рождения не может быть в будущем");

            return (true, "");
        }

        // проверка даты приема
        public static (bool ok, string error) ValidateHireDate(DateTime? hireDate, DateTime? birthDate)
        {
            if (hireDate == null)
                return (false, "Дата приема обязательна");

            if (birthDate != null)
            {
                var ageAtHire = (hireDate.Value - birthDate.Value).Days / 365;
                if (ageAtHire < 14)
                    return (false, "На дату приема работнику должно быть не менее 14 лет");
            }

            if (hireDate.Value > DateTime.Now.AddDays(30))
                return (false, "Дата приема не может быть более чем на 30 дней в будущем");

            return (true, "");
        }

        // проверка даты увольнения
        public static (bool ok, string error) ValidateFireDate(DateTime? fireDate, DateTime hireDate)
        {
            if (fireDate == null)
                return (false, "Укажите дату увольнения");
            if (fireDate < hireDate)
                return (false, "Дата увольнения не может быть раньше даты приема на работу");
            if (fireDate > DateTime.Now.AddDays(14))
                return (false, "Дата увольнения не может быть более чем на 14 дней в будущем (отработка по ст. 80 ТК РФ)");

            return (true, "");
        }

        // проверка телефона
        public static (bool ok, string error) ValidatePhone(string? phone)
        {
            if (string.IsNullOrWhiteSpace(phone)) return (true, "");

            var digits = new string(phone.Where(char.IsDigit).ToArray());
            if (digits.Length < 10 || digits.Length > 11)
                return (false, "Телефон должен содержать 10-11 цифр");

            return (true, "");
        }

        // проверка email
        public static (bool ok, string error) ValidateEmail(string? email)
        {
            if (string.IsNullOrWhiteSpace(email)) return (true, "");

            if (!Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$"))
                return (false, "Некорректный формат email");

            return (true, "");
        }

        // комплексная проверка сотрудника
        public static (bool ok, string error) ValidateEmployee(
            string lastName, string firstName, string? middleName,
            DateTime? birthDate, string? passport, string? snils, string? inn,
            string? phone, DateTime? hireDate, int departmentId, int positionId)
        {
            var checks = new[]
            {
                ValidateFio(lastName, firstName, middleName),
                ValidateBirthDate(birthDate),
                ValidatePassport(passport),
                ValidateSnils(snils),
                ValidateInn(inn),
                ValidatePhone(phone),
                ValidateHireDate(hireDate, birthDate),
            };

            foreach (var (ok, error) in checks)
                if (!ok) return (false, error);

            if (departmentId <= 0)
                return (false, "Выберите подразделение");
            if (positionId <= 0)
                return (false, "Выберите должность");

            return (true, "");
        }
    }
}
