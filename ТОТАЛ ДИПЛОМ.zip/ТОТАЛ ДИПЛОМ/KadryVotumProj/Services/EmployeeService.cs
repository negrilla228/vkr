using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using KadryVotumS.Data;
using KadryVotumS.Models;

namespace KadryVotumS.Services
{
    public class EmployeeService
    {
        public List<Employee> GetAll(string? search = null, int? deptId = null)
        {
            using var db = new AppDbContext();
            var q = db.Employees.Include(e => e.Department).Include(e => e.Position).AsQueryable();
            if (!string.IsNullOrWhiteSpace(search))
            {
                var s = search.ToLower();
                q = q.Where(e => e.LastName.ToLower().Contains(s) ||
                    e.FirstName.ToLower().Contains(s) ||
                    (e.MiddleName != null && e.MiddleName.ToLower().Contains(s)));
            }
            if (deptId.HasValue && deptId > 0)
                q = q.Where(e => e.DepartmentId == deptId.Value);
            return q.OrderBy(e => e.LastName).ToList();
        }

        public Employee? GetById(int id)
        {
            using var db = new AppDbContext();
            return db.Employees
                .Include(e => e.Department).Include(e => e.Position)
                .Include(e => e.Orders).Include(e => e.Vacations)
                .FirstOrDefault(e => e.Id == id);
        }

        public void Add(Employee emp)
        {
            using var db = new AppDbContext();
            var max = db.Employees.Any() ? db.Employees.Max(e => e.Id) : 0;
            emp.TabNumber = (max + 1).ToString("D4");
            db.Employees.Add(emp);
            db.SaveChanges();
            AuditService.Log("Добавлен сотрудник", "Employees", emp.Id, emp.FullName);
        }

        public void Update(Employee emp)
        {
            using var db = new AppDbContext();
            var ex = db.Employees.Find(emp.Id);
            if (ex == null) return;
            db.Entry(ex).CurrentValues.SetValues(emp);
            db.SaveChanges();
            AuditService.Log("Изменен сотрудник", "Employees", emp.Id);
        }

        public void Delete(int id)
        {
            using var db = new AppDbContext();
            var emp = db.Employees.Find(id);
            if (emp == null) return;
            emp.Status = "Уволен";
            emp.FireDate = DateTime.Now;
            db.SaveChanges();
            AuditService.Log("Уволен сотрудник", "Employees", id);
        }

        public (int total, int hired, int fired, int onVac) GetStats()
        {
            using var db = new AppDbContext();
            var now = DateTime.Now;
            var ms = new DateTime(now.Year, now.Month, 1);
            return (
                db.Employees.Count(e => e.Status != "Уволен"),
                db.Employees.Count(e => e.HireDate >= ms),
                db.Employees.Count(e => e.FireDate != null && e.FireDate >= ms),
                db.Vacations.Count(v => v.StartDate <= now && v.EndDate >= now)
            );
        }

        // расчет остатка отпуска
        public int GetVacationBalance(int empId)
        {
            using var db = new AppDbContext();
            var emp = db.Employees.Find(empId);
            if (emp == null) return 0;
            var months = (int)((DateTime.Now - emp.HireDate).TotalDays / 30.44);
            var earned = (int)(months * 28.0 / 12);
            var used = db.Vacations.Where(v => v.EmployeeId == empId)
                .AsEnumerable().Sum(v => v.Days);
            return Math.Max(0, earned - used);
        }
    }
}
