using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.EntityFrameworkCore;
using QuestPDF.Fluent;
using QuestPDF.Helpers;
using QuestPDF.Infrastructure;
using KadryVotumS.Data;
using KadryVotumS.Models;

namespace KadryVotumS.Services
{
    public class OrderService
    {
        public List<Order> GetAll()
        {
            using var db = new AppDbContext();
            return db.Orders.Include(o => o.Employee)
                .OrderByDescending(o => o.OrderDate).ToList();
        }

        public Order Create(int empId, string type, DateTime date, string? note = null)
        {
            using var db = new AppDbContext();
            var cnt = db.Orders.Count(o => o.Type == type) + 1;
            var order = new Order
            {
                EmployeeId = empId, Type = type, OrderDate = date,
                OrderNumber = $"{cnt:D3}", ContentJson = note
            };
            db.Orders.Add(order);
            db.SaveChanges();
            AuditService.Log($"Создан приказ {type} N{order.OrderNumber}", "Orders", order.Id);
            return order;
        }

        // генерация PDF по унифицированным формам
        public byte[] GeneratePdf(int orderId)
        {
            using var db = new AppDbContext();
            var order = db.Orders
                .Include(o => o.Employee).ThenInclude(e => e!.Department)
                .Include(o => o.Employee).ThenInclude(e => e!.Position)
                .First(o => o.Id == orderId);
            var emp = order.Employee!;

            QuestPDF.Settings.License = LicenseType.Community;

            return order.Type switch
            {
                "T1" => GenerateT1(order, emp),
                "T5" => GenerateT5(order, emp),
                "T8" => GenerateT8(order, emp),
                _ => GenerateT1(order, emp)
            };
        }

        // Форма Т-1: Приказ о приеме на работу (ОКУД 0301001)
        private byte[] GenerateT1(Order order, Employee emp)
        {
            return Document.Create(doc =>
            {
                doc.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.MarginTop(1.5f, Unit.Centimetre);
                    page.MarginBottom(1.5f, Unit.Centimetre);
                    page.MarginLeft(2, Unit.Centimetre);
                    page.MarginRight(1, Unit.Centimetre);

                    page.Content().Column(col =>
                    {
                        // шапка формы
                        col.Item().Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().Text("").FontSize(1);
                            });
                            row.ConstantItem(180).Column(c =>
                            {
                                c.Item().AlignRight().Text("Унифицированная форма N Т-1").FontSize(7);
                                c.Item().AlignRight().Text("Утверждена Постановлением Госкомстата").FontSize(6);
                                c.Item().AlignRight().Text("России от 05.01.2004 N 1").FontSize(6);
                            });
                        });

                        col.Item().PaddingTop(5).Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().BorderBottom(1).PaddingBottom(2)
                                    .Text("ООО \u00abВотум-С\u00bb").FontSize(10).Bold();
                                c.Item().AlignCenter().Text("наименование организации").FontSize(6).Italic();
                            });
                            row.ConstantItem(130).Column(c =>
                            {
                                c.Item().Text("Форма по ОКУД  0301001").FontSize(7);
                                c.Item().PaddingTop(3).Text("по ОКПО ___________").FontSize(7);
                            });
                        });

                        // номер и дата
                        col.Item().PaddingTop(15).Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().AlignCenter().Text("ПРИКАЗ").FontSize(12).Bold();
                                c.Item().AlignCenter().Text("(распоряжение)").FontSize(9);
                            });
                        });

                        col.Item().PaddingTop(3).Row(row =>
                        {
                            row.RelativeItem().AlignCenter()
                                .Text($"N  {order.OrderNumber}  от  \u00ab {order.OrderDate:dd} \u00bb  {GetMonthName(order.OrderDate.Month)}  {order.OrderDate.Year} г.").FontSize(10);
                        });

                        col.Item().PaddingTop(10).AlignCenter()
                            .Text("о приеме работника на работу").FontSize(11).Bold();

                        // дата приема
                        col.Item().PaddingTop(15).Row(row =>
                        {
                            row.RelativeItem().Text(t =>
                            {
                                t.Span("Принять на работу с  ").FontSize(10);
                                t.Span($"\u00ab {emp.HireDate:dd} \u00bb {GetMonthName(emp.HireDate.Month)} {emp.HireDate.Year} г.").FontSize(10).Underline();
                            });
                        });

                        // ФИО
                        col.Item().PaddingTop(15).BorderBottom(1).PaddingBottom(3)
                            .Text($"{emp.LastName} {emp.FirstName} {emp.MiddleName}").FontSize(11).Bold();
                        col.Item().AlignCenter().Text("фамилия, имя, отчество").FontSize(6).Italic();

                        // подразделение
                        col.Item().PaddingTop(10).Text(t =>
                        {
                            t.Span("в  ").FontSize(10);
                            t.Span($"{emp.Department?.Name}").FontSize(10).Underline();
                        });
                        col.Item().AlignCenter().Text("структурное подразделение").FontSize(6).Italic();

                        // должность
                        col.Item().PaddingTop(8).BorderBottom(1).PaddingBottom(3)
                            .Text($"{emp.Position?.Title}").FontSize(10);
                        col.Item().AlignCenter()
                            .Text("должность (специальность, профессия), разряд, класс (категория) квалификации").FontSize(6).Italic();

                        // условия
                        col.Item().PaddingTop(8).Text(t =>
                        {
                            t.Span("Условия приема на работу, характер работы:  ").FontSize(9);
                            t.Span("основное место работы, постоянно").FontSize(9).Underline();
                        });

                        // оклад
                        col.Item().PaddingTop(10).Text(t =>
                        {
                            t.Span("с тарифной ставкой (окладом)  ").FontSize(10);
                            t.Span($"{emp.Position?.Salary:N2}").FontSize(10).Bold().Underline();
                            t.Span("  руб.").FontSize(10);
                        });

                        col.Item().PaddingTop(3).Text("надбавка _____________________ руб.").FontSize(10);

                        // испытательный срок
                        col.Item().PaddingTop(8).Text(t =>
                        {
                            t.Span("с испытанием на срок  ").FontSize(10);
                            t.Span("3 (три)").FontSize(10).Underline();
                            t.Span("  месяца(ев)").FontSize(10);
                        });

                        // основание
                        col.Item().PaddingTop(10).Text(t =>
                        {
                            t.Span("Основание: трудовой договор от  ").FontSize(10);
                            t.Span($"\u00ab {emp.HireDate:dd} \u00bb {GetMonthName(emp.HireDate.Month)} {emp.HireDate.Year} г.").FontSize(10).Underline();
                            t.Span($"  N ____").FontSize(10);
                        });

                        // подписи
                        col.Item().PaddingTop(25).Text(t =>
                        {
                            t.Span("Руководитель организации  ____________  __________________").FontSize(10);
                        });
                        col.Item().AlignRight().PaddingRight(40)
                            .Text("должность         подпись       расшифровка подписи").FontSize(6).Italic();

                        col.Item().PaddingTop(20).Text(t =>
                        {
                            t.Span("С приказом (распоряжением) работник ознакомлен  ______________  ").FontSize(9);
                            t.Span($"\u00ab__\u00bb __________ {order.OrderDate.Year} г.").FontSize(9);
                        });
                        col.Item().PaddingLeft(280).Text("подпись").FontSize(6).Italic();
                    });
                });
            }).GeneratePdf();
        }

        // Форма Т-5: Приказ о переводе (ОКУД 0301004)
        private byte[] GenerateT5(Order order, Employee emp)
        {
            return Document.Create(doc =>
            {
                doc.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.MarginTop(1.5f, Unit.Centimetre);
                    page.MarginBottom(1.5f, Unit.Centimetre);
                    page.MarginLeft(2, Unit.Centimetre);
                    page.MarginRight(1, Unit.Centimetre);

                    page.Content().Column(col =>
                    {
                        col.Item().Row(row =>
                        {
                            row.RelativeItem().Text("").FontSize(1);
                            row.ConstantItem(180).Column(c =>
                            {
                                c.Item().AlignRight().Text("Унифицированная форма N Т-5").FontSize(7);
                                c.Item().AlignRight().Text("Утверждена Постановлением Госкомстата").FontSize(6);
                                c.Item().AlignRight().Text("России от 05.01.2004 N 1").FontSize(6);
                            });
                        });

                        col.Item().PaddingTop(5).Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().BorderBottom(1).PaddingBottom(2)
                                    .Text("ООО \u00abВотум-С\u00bb").FontSize(10).Bold();
                                c.Item().AlignCenter().Text("наименование организации").FontSize(6).Italic();
                            });
                            row.ConstantItem(130).Text("Форма по ОКУД  0301004").FontSize(7);
                        });

                        col.Item().PaddingTop(15).AlignCenter().Text("ПРИКАЗ").FontSize(12).Bold();
                        col.Item().AlignCenter().Text("(распоряжение)").FontSize(9);
                        col.Item().PaddingTop(3).AlignCenter()
                            .Text($"N  {order.OrderNumber}  от  \u00ab {order.OrderDate:dd} \u00bb  {GetMonthName(order.OrderDate.Month)}  {order.OrderDate.Year} г.").FontSize(10);

                        col.Item().PaddingTop(10).AlignCenter()
                            .Text("о переводе работника на другую работу").FontSize(11).Bold();

                        col.Item().PaddingTop(10).Text("Перевести на другую работу").FontSize(10);
                        col.Item().PaddingTop(3).Text(t =>
                        {
                            t.Span("Вид перевода: ").FontSize(10);
                            t.Span("постоянно").FontSize(10).Underline();
                        });

                        // ФИО
                        col.Item().PaddingTop(10).BorderBottom(1).PaddingBottom(3)
                            .Text($"{emp.LastName} {emp.FirstName} {emp.MiddleName}").FontSize(11).Bold();
                        col.Item().AlignCenter().Text("фамилия, имя, отчество").FontSize(6).Italic();

                        col.Item().PaddingTop(5).Text($"Табельный номер: {emp.TabNumber}").FontSize(10);

                        // прежнее место
                        col.Item().PaddingTop(10).Text("Прежнее место работы:").FontSize(10).Bold();
                        col.Item().Text($"структурное подразделение: {emp.Department?.Name ?? "_______________"}").FontSize(10);
                        col.Item().Text($"должность: {emp.Position?.Title ?? "_______________"}").FontSize(10);

                        // новое место
                        col.Item().PaddingTop(10).Text("Новое место работы:").FontSize(10).Bold();
                        col.Item().Text($"структурное подразделение: {emp.Department?.Name ?? "_______________"}").FontSize(10);
                        col.Item().Text($"должность: {emp.Position?.Title ?? "_______________"}").FontSize(10);
                        col.Item().Text(t =>
                        {
                            t.Span("тарифная ставка (оклад): ").FontSize(10);
                            t.Span($"{emp.Position?.Salary:N2}").FontSize(10).Bold();
                            t.Span(" руб.").FontSize(10);
                        });

                        col.Item().PaddingTop(8).Text(t =>
                        {
                            t.Span("Причина перевода: ").FontSize(10);
                            t.Span(order.ContentJson ?? "по заявлению работника").FontSize(10).Underline();
                        });

                        col.Item().PaddingTop(8).Text(t =>
                        {
                            t.Span("Основание: изменение к трудовому договору от ").FontSize(10);
                            t.Span($"\u00ab {order.OrderDate:dd} \u00bb {GetMonthName(order.OrderDate.Month)} {order.OrderDate.Year} г.").FontSize(10);
                        });

                        col.Item().PaddingTop(25).Text("Руководитель организации  ____________  __________________").FontSize(10);
                        col.Item().PaddingTop(20).Text(t =>
                        {
                            t.Span("С приказом ознакомлен  ______________  ").FontSize(9);
                            t.Span($"\u00ab__\u00bb __________ {order.OrderDate.Year} г.").FontSize(9);
                        });
                    });
                });
            }).GeneratePdf();
        }

        // Форма Т-8: Приказ об увольнении (ОКУД 0301006)
        private byte[] GenerateT8(Order order, Employee emp)
        {
            return Document.Create(doc =>
            {
                doc.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.MarginTop(1.5f, Unit.Centimetre);
                    page.MarginBottom(1.5f, Unit.Centimetre);
                    page.MarginLeft(2, Unit.Centimetre);
                    page.MarginRight(1, Unit.Centimetre);

                    page.Content().Column(col =>
                    {
                        col.Item().Row(row =>
                        {
                            row.RelativeItem().Text("").FontSize(1);
                            row.ConstantItem(180).Column(c =>
                            {
                                c.Item().AlignRight().Text("Унифицированная форма N Т-8").FontSize(7);
                                c.Item().AlignRight().Text("Утверждена Постановлением Госкомстата").FontSize(6);
                                c.Item().AlignRight().Text("России от 05.01.2004 N 1").FontSize(6);
                            });
                        });

                        col.Item().PaddingTop(5).Row(row =>
                        {
                            row.RelativeItem().Column(c =>
                            {
                                c.Item().BorderBottom(1).PaddingBottom(2)
                                    .Text("ООО \u00abВотум-С\u00bb").FontSize(10).Bold();
                                c.Item().AlignCenter().Text("наименование организации").FontSize(6).Italic();
                            });
                            row.ConstantItem(130).Text("Форма по ОКУД  0301006").FontSize(7);
                        });

                        col.Item().PaddingTop(15).AlignCenter().Text("ПРИКАЗ").FontSize(12).Bold();
                        col.Item().AlignCenter().Text("(распоряжение)").FontSize(9);
                        col.Item().PaddingTop(3).AlignCenter()
                            .Text($"N  {order.OrderNumber}  от  \u00ab {order.OrderDate:dd} \u00bb  {GetMonthName(order.OrderDate.Month)}  {order.OrderDate.Year} г.").FontSize(10);

                        col.Item().PaddingTop(10).AlignCenter()
                            .Text("о прекращении (расторжении) трудового договора").FontSize(10).Bold();
                        col.Item().AlignCenter()
                            .Text("с работником (увольнении)").FontSize(10).Bold();

                        col.Item().PaddingTop(10).Text(t =>
                        {
                            t.Span("Прекратить действие трудового договора от ").FontSize(10);
                            t.Span($"\u00ab {emp.HireDate:dd} \u00bb {GetMonthName(emp.HireDate.Month)} {emp.HireDate.Year} г.").FontSize(10);
                        });

                        col.Item().PaddingTop(3).Text(t =>
                        {
                            t.Span("Уволить  ").FontSize(10);
                            t.Span($"\u00ab {(emp.FireDate ?? order.OrderDate):dd} \u00bb {GetMonthName((emp.FireDate ?? order.OrderDate).Month)} {(emp.FireDate ?? order.OrderDate).Year} г.").FontSize(10).Underline();
                        });

                        // ФИО
                        col.Item().PaddingTop(12).BorderBottom(1).PaddingBottom(3)
                            .Text($"{emp.LastName} {emp.FirstName} {emp.MiddleName}").FontSize(11).Bold();
                        col.Item().AlignCenter().Text("фамилия, имя, отчество").FontSize(6).Italic();

                        col.Item().PaddingTop(5).Text($"Табельный номер: {emp.TabNumber}").FontSize(10);

                        col.Item().PaddingTop(5).Text($"Структурное подразделение: {emp.Department?.Name}").FontSize(10);
                        col.Item().Text($"Должность: {emp.Position?.Title}").FontSize(10);

                        // основание увольнения
                        col.Item().PaddingTop(12).Text("Основание прекращения (расторжения)").FontSize(10);
                        col.Item().Text("трудового договора (увольнения):").FontSize(10);
                        col.Item().PaddingTop(3).BorderBottom(1).PaddingBottom(3)
                            .Text(order.ContentJson ?? "по инициативе работника (собственное желание), п. 3 ч. 1 ст. 77 ТК РФ").FontSize(10);

                        col.Item().PaddingTop(8).Text("Основание (документ, номер, дата): заявление работника").FontSize(10);

                        col.Item().PaddingTop(25).Text("Руководитель организации  ____________  __________________").FontSize(10);
                        col.Item().AlignRight().PaddingRight(40)
                            .Text("должность         подпись       расшифровка подписи").FontSize(6).Italic();

                        col.Item().PaddingTop(20).Text(t =>
                        {
                            t.Span("С приказом ознакомлен  ______________  ").FontSize(9);
                            t.Span($"\u00ab__\u00bb __________ {order.OrderDate.Year} г.").FontSize(9);
                        });
                    });
                });
            }).GeneratePdf();
        }


        // Заявление об увольнении по собственному желанию
        public byte[] GenerateResignationLetter(int empId, DateTime lastDay)
        {
            using var db = new AppDbContext();
            var emp = db.Employees
                .Include(e => e.Department)
                .Include(e => e.Position)
                .First(e => e.Id == empId);

            QuestPDF.Settings.License = LicenseType.Community;

            return Document.Create(doc =>
            {
                doc.Page(page =>
                {
                    page.Size(PageSizes.A4);
                    page.MarginTop(2, Unit.Centimetre);
                    page.MarginBottom(2, Unit.Centimetre);
                    page.MarginLeft(3, Unit.Centimetre);
                    page.MarginRight(1.5f, Unit.Centimetre);

                    page.Content().Column(col =>
                    {
                        // шапка справа
                        col.Item().AlignRight().PaddingRight(10).Column(right =>
                        {
                            right.Item().Text("Генеральному директору").FontSize(12);
                            right.Item().Text("ООО \u00abВотум-С\u00bb").FontSize(12);
                            right.Item().Text("____________________________").FontSize(12);
                            right.Item().Text("(Ф.И.О. руководителя)").FontSize(8).Italic();
                            right.Item().PaddingTop(10).Text($"от {emp.Position?.Title}").FontSize(12);
                            right.Item().Text($"{emp.Department?.Name}").FontSize(12);
                            right.Item().Text($"{emp.FullName}").FontSize(12).Bold();
                        });

                        // заголовок
                        col.Item().PaddingTop(40).AlignCenter()
                            .Text("ЗАЯВЛЕНИЕ").FontSize(14).Bold();

                        // текст заявления
                        col.Item().PaddingTop(20).Text(t =>
                        {
                            t.Span("     Прошу уволить меня с занимаемой должности ").FontSize(12);
                            t.Span($"{emp.Position?.Title} ").FontSize(12).Bold();
                            t.Span("по собственному желанию на основании п. 3 ч. 1 ст. 77 Трудового кодекса ").FontSize(12);
                            t.Span($"Российской Федерации с ").FontSize(12);
                            t.Span($"\u00ab{lastDay:dd}\u00bb {GetMonthName(lastDay.Month)} {lastDay.Year} г.").FontSize(12).Bold();
                        });

                        // дата и подпись
                        col.Item().PaddingTop(50).Row(row =>
                        {
                            row.RelativeItem().Text($"\u00ab__\u00bb __________ {DateTime.Now.Year} г.").FontSize(12);
                            row.ConstantItem(200).Column(c =>
                            {
                                c.Item().Text("______________").FontSize(12);
                                c.Item().AlignCenter().Text("(подпись)").FontSize(8).Italic();
                            });
                        });

                        col.Item().PaddingTop(10).AlignRight().PaddingRight(30)
                            .Text($"/{emp.LastName} {emp.FirstName[0]}.{(emp.MiddleName != null && emp.MiddleName.Length > 0 ? emp.MiddleName[0] + "." : "")}/").FontSize(12);
                    });
                });
            }).GeneratePdf();
        }

        private static string GetMonthName(int month) => month switch
        {
            1 => "января", 2 => "февраля", 3 => "марта", 4 => "апреля",
            5 => "мая", 6 => "июня", 7 => "июля", 8 => "августа",
            9 => "сентября", 10 => "октября", 11 => "ноября", 12 => "декабря",
            _ => ""
        };
    }
}
